<?php $__env->startSection('content'); ?>

<div class="dashboard-hero-content text-white">
    <h3 class="title"><?php echo e($page_title); ?></h3>
    <ul class="breadcrumb">
        <li class="nav-item">  <a class="nav-link " href="index.html">Home</a> </li>
        <li>
            <?php echo e($page_title); ?>

        </li>
    </ul>
</div>
</div>
<div class="container-fluid">
    <div class="operations">
        <h3 class="main-title"><?php echo e($page_title); ?></h3>

        <div class="table-wrapper">
            <table class="transaction-table" >
                <thead>
                    <tr>
                        <th scope="col"><?php echo app('translator')->get('Transaction ID'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('Amount'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('Request From'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('datetime'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('Action'); ?></th>
                    </tr>
                </thead>
                <tbody>

                    <?php if($requests->count() == 0): ?>
                        <tr>
                            <td class="text-center" colspan="5">
                                <?php echo app('translator')->get('No data found'); ?>
                            </td>

                        </tr>
                    <?php endif; ?>

                    <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class=""><?php echo e($request->trx); ?></td>
                            <td class=""><?php echo e($request->final_amount); ?></td>
                            <td class=""><?php echo e($request->user->username); ?></td>
                            <td class=""><?php echo e(show_datetime($request->created_at)); ?></td>

                            <td>
                                <button class="btn btn-success approveBtn"  data-id="<?php echo e($request->id); ?>" data-amount="<?php echo e(formatter_money($request->final_amount)); ?> <?php echo e($gnl->cur_sym); ?>"><i class="fa fa-fw fa-check"></i></button><br>
                                <button class="btn btn-danger rejectBtn" data-id="<?php echo e($request->id); ?>" data-amount="<?php echo e(formatter_money($request->final_amount)); ?> <?php echo e($gnl->cuur_sym); ?>"><i class="fa fa-fw fa-ban"></i></button>
                            </td>




                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
            </table>

            <ul class="pagination-overfollow">
                <p><?php echo e($requests->appends(array_filter(Request::all()))->links( "pagination::bootstrap-5")); ?></p>
            </ul>
        </div>
    </div>

</div>

    
    <div id="approveModal" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Approve Request Confirmation'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('user.ownbank.request.approve')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id">
                    <div class="modal-body">
                        <p><?php echo app('translator')->get('Sure! you want to Sent '); ?><span class="font-weight-bold transfer-amount text-success"></span>?</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-warning" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn btn-success"><?php echo app('translator')->get('Approve'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <div id="rejectModal" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Reject request Confirmation'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('user.ownbank.request.reject')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id">
                    <div class="modal-body">
                        <strong><?php echo app('translator')->get('Reject the request'); ?></strong>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-warning" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn btn-danger"><?php echo app('translator')->get('Reject'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        $('.approveBtn').on('click', function() {
            var modal = $('#approveModal');
            modal.find('input[name=id]').val($(this).data('id'));
            modal.find('.transfer-amount').text($(this).data('amount'));
            modal.modal('show');
        });

        $('.rejectBtn').on('click', function() {
            var modal = $('#rejectModal');
            modal.find('input[name=id]').val($(this).data('id'));
            modal.find('.transfer-amount').text($(this).data('amount'));
            modal.modal('show');
        });

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('users.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\newproject\bank-fund-transfer\resources\views/users/request/pending.blade.php ENDPATH**/ ?>