<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-title"><?php echo e($page_title); ?></div>
                </div>
                <div class="card-body">
                    <form id="exampleValidation" method="post" action="<?php echo e(route('admin.settings.basic')); ?>"
                          enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row" >
                            <div class="col-md-4 mb-3">
                                <div class="form-group ">
                                    <label class="mb-2"><?php echo app('translator')->get('Site Name'); ?></label>
                                    <input type="text" class="form-control  form-control-lg"
                                        value="<?php echo e($gnl->site_name); ?>" name="site_name" placeholder="Enter site name" required>

                                </div>
                            </div>

                            <div class="form-group col-md-2 mb-3" >
                                <label class="mb-2" > <?php echo app('translator')->get('Site Currency'); ?> </label>
                                <input type="text" class="form-control form-control-lg "
                                       value="<?php echo e($gnl->cur); ?>" placeholder="site currency" name="currency" required>
                            </div>

                            <div class="form-group col-md-3 mb-3">
                                <label class="mb-2"><?php echo app('translator')->get('Site Currency Symbol'); ?></label>
                                <input type="text" class="form-control form-control-lg  "
                                       value="<?php echo e($gnl->cur_sym); ?>" placeholder="site currency" name="currency_symbol"
                                       required>


                            </div>
                            <div class="form-group col-md-3 mb-3">
                                <label class="mb-2"><?php echo app('translator')->get('Need Admin Approval'); ?></label>
                                <select class="form-control form-control-lg " name="admin_permission">
                                    <option value="1"><?php echo app('translator')->get('Yes'); ?></option>
                                    <option value="0"><?php echo app('translator')->get('No'); ?></option>

                                </select>
                            </div>

                            <div class="col-md-4 mb-3">
                                <div class="form-group">
                                    <label class="form-label"><?php echo app('translator')->get('Email Verification'); ?></label>
                                    <div class="selectgroup w-100">
                                        <input type="radio" class="btn-check" name="email_verification" id="eev"
                                        autocomplete="off" value="1" <?php echo e($gnl->ev == '1' ? 'checked' : ''); ?>  >
                                    <label class="btn btn-outline-success-custom " for="eev">Enable</label>

                                    <input type="radio" class="btn-check" name="email_verification" id="dev"
                                        autocomplete="off" value="0" <?php echo e($gnl->ev != '1' ? 'checked' : ''); ?>  >
                                    <label class="btn btn-outline-danger-custom" for="dev"> Disable</label>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4 mb-3">
                                <div class="form-group">
                                    <label class="form-label"><?php echo app('translator')->get('Email Notification'); ?></label>
                                    <div class="selectgroup w-100">
                                        <input type="radio" class="btn-check" name="email_notification" id="een"
                                        autocomplete="off" value="1" <?php echo e($gnl->en == '1' ? 'checked' : ''); ?>  >
                                    <label class="btn btn-outline-success-custom " for="een">Enable</label>

                                    <input type="radio" class="btn-check" name="email_notification" id="den"
                                        autocomplete="off" value="0" <?php echo e($gnl->en != '1' ? 'checked' : ''); ?>  >
                                    <label class="btn btn-outline-danger-custom " for="den"> Disable</label>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4 mb-3">
                                <div class="form-group">
                                    <label class="form-label"><?php echo app('translator')->get('SMS Verification'); ?></label>
                                    <div class="selectgroup w-100">
                                        <input type="radio" class="btn-check" name="sms_verification" id="esv"
                                        autocomplete="off" value="1" <?php echo e($gnl->sv == '1' ? 'checked' : ''); ?>  >
                                    <label class="btn btn-outline-success-custom " for="esv">Enable</label>

                                    <input type="radio" class="btn-check" name="sms_verification" id="dsv"
                                        autocomplete="off" value="0" <?php echo e($gnl->sv != '1' ? 'checked' : ''); ?>  >
                                    <label class="btn btn-outline-danger-custom " for="dsv"> Disable</label>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4 mb-3">
                                <div class="form-group">
                                    <label class="form-label"><?php echo app('translator')->get('SMS Notification'); ?></label>
                                    <div class="selectgroup w-100">
                                        <input type="radio" class="btn-check" name="sms_notification" id="esn"
                                        autocomplete="off" value="1" <?php echo e($gnl->sn == '1' ? 'checked' : ''); ?>  >
                                    <label class="btn btn-outline-success-custom " for="esn">Enable</label>

                                    <input type="radio" class="btn-check" name="sms_notification" id="dsn"
                                        autocomplete="off" value="0" <?php echo e($gnl->sn != '1' ? 'checked' : ''); ?>  >
                                    <label class="btn btn-outline-danger-custom " for="dsn"> Disable</label>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4 mb-3">
                                <div class="form-group">
                                    <label class="form-label"><?php echo app('translator')->get('User Registration'); ?></label>
                                    <div class="selectgroup w-100">
                                        <input type="radio" class="btn-check" name="registration" id="ereg"
                                        autocomplete="off" value="1" <?php echo e($gnl->reg == '1' ? 'checked' : ''); ?>  >
                                    <label class="btn btn-outline-success-custom " for="ereg">Enable</label>

                                    <input type="radio" class="btn-check" name="registration" id="dreg"
                                        autocomplete="off" value="0" <?php echo e($gnl->reg != '1' ? 'checked' : ''); ?>  >
                                    <label class="btn btn-outline-danger-custom " for="dreg"> Disable</label>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4 mb-3">
                                <div class="form-group">
                                    <label class="form-label"><?php echo app('translator')->get('User Login'); ?></label>
                                    <div class="selectgroup w-100">
                                        <input type="radio" class="btn-check" name="login" id="elog"
                                        autocomplete="off" value="1" <?php echo e($gnl->login_status == '1' ? 'checked' : ''); ?>  >
                                    <label class="btn btn-outline-success-custom " for="elog">Enable</label>

                                    <input type="radio" class="btn-check" name="login" id="dlog"
                                        autocomplete="off" value="0" <?php echo e($gnl->login_status != '1' ? 'checked' : ''); ?>  >
                                    <label class="btn btn-outline-danger-custom " for="dlog"> Disable</label>
                                    </div>
                                </div>
                            </div>


                            <div class="form-group col-md-6 mb-3">
                                <label for="basicInput" class="mb-2">User Registration Off Message</label>
                                <input type="text"
                                       class="form-control  form-control-lg " id="basicInput"
                                       value="<?php echo e($gnl->res_mes); ?>" name="registration_off_message"
                                       placeholder="User Registration Off Message">


                                <span class="text-warning">If user registration off message is null, there is a default message</span>

                            </div>

                            <div class="form-group col-md-6 mb-3">
                                <label class="mb-2">User Login Off Message</label>
                                <input type="text"
                                       class="form-control  form-control-lg "
                                       value="<?php echo e($gnl->login_mes); ?>" name="login_off_message"
                                       placeholder="User Login Off Message">

                                <span
                                    class="text-warning">If user login off message is null, there is a default message</span>
                            </div>

                            <div class="card-title">Transfer Charges </div>

                            <div class="col-md-6 ">
                                <label for="basicInput" class="mb-2">Percent Charge </label>
                                <div class="input-group mb-3">
                                    <input type="text" name="percent_charge" value="<?php echo e(formatter_money($gnl->percent_charge)); ?>" class="form-control form-control-lg"
                                        aria-label="percent_charge" aria-describedby="basic-addon1" required >
                                    <span class="input-group-text" id="basic-addon1">%</span>
                                </div>
                            </div>
                            <div class="col-md-6 ">
                                <label for="basicInput" class="mb-2">Fixed Charge </label>
                                <div class="input-group mb-3">
                                    <input type="text" name="fixed_charge" value="<?php echo e(formatter_money($gnl->fixed_charge)); ?>" class="form-control form-control-lg"
                                        aria-label="fixed_charge" aria-describedby="basic-addon1" required>
                                    <span class="input-group-text" id="basic-addon1"><?php echo e($gnl->cur_sym); ?></span>
                                </div>
                            </div>

                        </div>

                       <div class="card-action mt-5">
                            <button class="btn btn-success btn-block"><?php echo app('translator')->get('Submit'); ?></button>
                        </div>
                    </form>

                </div>

            </div>
        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('js_link'); ?>
    <?php echo $__env->make('partials.validation_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $("select[name=admin_permission]").val("<?php echo e($gnl->admin_permission); ?>");
    </script>
<?php $__env->stopPush(); ?>




<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\newproject\bank-fund-transfer\resources\views/admin/basic/index.blade.php ENDPATH**/ ?>