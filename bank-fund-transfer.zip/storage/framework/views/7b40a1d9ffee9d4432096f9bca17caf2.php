<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">

                <div class="card-header">
                    <div class="card-title"><?php echo e($page_title); ?> <?php echo app('translator')->get('Section'); ?></div>
                </div>
                <form  class="exampleValidation" action="<?php echo e(route('admin.settings.footer')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="card-body  ">
                        <div class="row justify-content-center">
                            <div class="form-group col-md-12 mb-4">
                                <label for="" class="mb-2"><?php echo app('translator')->get('Footer Text'); ?> *</label>
                                <input type="text" class="form-control form-control-lg" name="footer_text" value="<?php echo e($gnl->footer_text); ?>"
                                       placeholder="Enter service title">
                            </div>
                            <div class="form-group col-md-12">
                                <label for="" class="mb-2"><?php echo app('translator')->get('Copyright Text'); ?> *</label>
                                <input type="text" class="form-control form-control-lg" name="copy_section" value="<?php echo e($gnl->copy_section); ?>"
                                       placeholder="Enter service subtitle">

                            </div>
                        </div>
                    </div>
                    <div class="card-footer pt-3">
                        <div class="col-12 text-center">
                            <button type="submit" class="btn btn-success btn-block"><?php echo app('translator')->get('Update'); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\newproject\bank-fund-transfer\resources\views/admin/footer.blade.php ENDPATH**/ ?>