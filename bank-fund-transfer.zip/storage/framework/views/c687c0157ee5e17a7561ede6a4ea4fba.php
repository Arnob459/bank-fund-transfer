<?php $__env->startSection('content'); ?>

                <section class="section">
                    <div class="card">
                        <div class="card-header">
                            <?php echo e($page_title); ?>

                        </div>
                        <div class="card-body" >
                            <div class="table-responsive">
                            <table class="table table-hover" id="table1">
                                <thead>
                                    <tr style="white-space: nowrap">
                                        <th>Avatar</th>
                                        <th>Name</th>
                                        <th>Username</th>
                                        <th>Email</th>
                                        <th>Balance</th>
                                        <th>Status</th>
                                        <th>Actions</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td>
                                             <?php if($user->avatar !=null): ?>
                                             <div class="avatar  ">
                                            <img class="avatar-img rounded-circle" src="<?php echo e(asset('assets/images/users/'.$user->avatar)); ?>" >
                                            </div>
                                            <?php else: ?>
                                            <div class="avatar avatar-xl">
                                            <span class="avatar-text rounded-circle border border-dark"><?php echo e(\Illuminate\Support\Str::limit($user->name, 1 ,'')); ?></span>
                                        </div>

                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><a href="<?php echo e(route('admin.user.edit', $user->id)); ?>"> <?php echo e($user->username); ?> </a></td>
                                        <td ><?php echo e($user->email); ?></td>
                                        <td><?php echo e($gnl->cur_sym); ?> <?php echo e(formatter_money($user->balance)); ?></td>
                                        <td>
                                        <?php if($user->status == 1): ?>
                                        <span class="badge bg-success">Active</span>
                                        <?php elseif($user->status == 0): ?>
                                        <span class="badge bg-danger">Block</span>
                                        <?php else: ?>
                                        <span class="badge bg-warning">Pending</span>
                                        <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('admin.user.edit',$user->id)); ?>" class="btn icon btn-primary"><i class="bi bi-pencil"></i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <?php if(count($users) == 0): ?>
                                            <td colspan="10" class="text-center">No users found</td>
                                        <?php endif; ?>
                                    </tr>

                                </tbody>
                            </table>
                            <ul class="pagination-overfollow">
                                <p><?php echo e($users->appends(array_filter(Request::all()))->links( "pagination::bootstrap-5")); ?></p>
                            </ul>

                        </div>
                        </div>
                    </div>

                </section>
            </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\newproject\bank-fund-transfer\resources\views/admin/users/all_users.blade.php ENDPATH**/ ?>