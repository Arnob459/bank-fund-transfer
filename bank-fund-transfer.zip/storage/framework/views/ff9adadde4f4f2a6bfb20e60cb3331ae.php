<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title><?php echo e($gnl->site_name); ?> | <?php echo e($page_title?? ''); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/bootstrap.min.css')); ?>">


    
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/animate.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/odometer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/nice-select.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/owl.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/jquery-ui.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/magnific-popup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/flaticon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/fontawesome-5.15.4/css/all.min.css')); ?>">
    <!-- Toastr CSS -->
    



    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/logo/'.$gnl->favicon)); ?>" type="image/x-icon">
</head>
        <?php if(session()->has('toastr')): ?>
        <?php echo session('toastr'); ?>

        <?php endif; ?>

<body>
    <div class="main--body dashboard-bg">
        <!--========== Preloader ==========-->
        <div class="loader">
            <div class="loader-inner">
                <div class="loader-line-wrap">
                    <div class="loader-line"></div>
                </div>
                <div class="loader-line-wrap">
                    <div class="loader-line"></div>
                </div>
                <div class="loader-line-wrap">
                    <div class="loader-line"></div>
                </div>
                <div class="loader-line-wrap">
                    <div class="loader-line"></div>
                </div>
                <div class="loader-line-wrap">
                    <div class="loader-line"></div>
                </div>
            </div>
        </div>
        <div class="overlay"></div>
        <!--========== Preloader ==========-->


        <!--=======SideHeader-Section Starts Here=======-->
        <div class="notify-overlay"></div>
        <section class="dashboard-section">
            <div class="side-header oh">
                <div class="cross-header-bar d-xl-none">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="site-header-container">
                    <div class="side-logo mt-2">
                        <a href="">
                            <img src="<?php echo e(asset('assets/images/logo/'.$gnl->logo)); ?>" alt="logo">
                        </a>
                    </div>
                    <ul class="dashboard-menu">

                        <li class="nav-item">Request Money
                        </li>
                        <li class="nav-item"><a class="nav-link <?php echo e(Route::is('user.ownbank.requestmoney') ? 'active' : ''); ?>"href="<?php echo e(route('user.ownbank.requestmoney')); ?>"><i class="flaticon-atm"></i>Request Money</a>
                        <li class="nav-item">Send Money
                        </li>
                        <li class="nav-item"><a class="nav-link <?php echo e(Route::is('user.ownbank.sendmoney') ? 'active' : ''); ?>"href="<?php echo e(route('user.ownbank.sendmoney')); ?>"><i class="flaticon-atm"></i>Own Bank</a>
                        </li>

                        <li class="nav-item"><a class="nav-link <?php echo e(Route::is('user.sendmoney') ? 'active' : ''); ?>"href="<?php echo e(route('user.sendmoney')); ?>"><i class="flaticon-atm"></i>Others Bank</a>
                        </li>


                    </ul>
                </div>
            </div>


            <div class="dasboard-body">
                <div class="dashboard-hero">
                    <div class="header-top">
                        <div class="container">
                            <div class="mobile-header d-flex justify-content-between d-lg-none align-items-center">
                                <div class="author">
                                    <img src="" alt="dashboard">
                                </div>
                                <div class="cross-header-bar">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </div>
                            </div>
                            <div class="mobile-header-content d-lg-flex flex-wrap justify-content-lg-between align-items-center">
                                <ul class="support-area">
                                    <li>
                                        
                                    </li>
                                    <li>
                                        <a href="Mailto:<?php echo e($gnl_extra->contact_email); ?>"><i class="flaticon-email"></i><span class="__cf_email__" data-cfemail="f49d9a929bb49c8d9d8498959a90da979b99">[email&#160;protected]</span> </a>
                                    </li>
                                    <li>
                                        <i class="flaticon-globe"></i>
                                        <div class="select-area">
                                            <select class="select-bar" style="display: none;">
                                                <option value="en">English</option>
                                                <option value="bn">Bangla</option>
                                                <option value="sp">Spanish</option>
                                            </select>
                                        </div>
                                    </li>
                                </ul>
                                <div class="dashboard-header-right d-flex flex-wrap justify-content-center justify-content-sm-between justify-content-lg-end align-items-center">

                                    <ul class="dashboard-right-menus">
                                        <li>
                                            <a href="#0" class="author nav-link">
                                                <div class="thumb">
                                                        <?php if(auth()->user()->avatar == null): ?>
                                                        <img  src="<?php echo e(asset('assets/images/user.png')); ?>" alt="">
                                                        <?php else: ?>
                                                            <img src="<?php echo e(asset('assets/images/users/'.auth()->user()->avatar)); ?>" >
                                                        <?php endif; ?>
                                                    <span class="checked">
                                                        <i class="flaticon-checked"></i>
                                                    </span>
                                                </div>
                                                <div class="content">
                                                    <h6 class="title"><?php echo e(auth()->user()->name); ?></h6>
                                                </div>
                                            </a>
                                            <div class="notification-area">
                                                <div class="author-header">
                                                    <div class="thumb">
                                                        <?php if(auth()->user()->avatar == null): ?>
                                                        <img  src="<?php echo e(asset('assets/images/user.png')); ?>" alt="">
                                                        <?php else: ?>
                                                            <img src="<?php echo e(asset('assets/images/users/'.auth()->user()->avatar)); ?>" >
                                                        <?php endif; ?>
                                                    </div>
                                                    <h6 class="title"><?php echo e(auth()->user()->name); ?></h6>
                                                    <span class="__cf_email__"><?php echo e(auth()->user()->email); ?></span>
                                                </div>
                                                <div class="author-body">
                                                    <ul>
                                                        <li>
                                                            <a href="<?php echo e(route('user.profile')); ?>"><i class="far fa-user"></i>Profile</a>
                                                        </li>
                                                        <li>
                                                            <a href="<?php echo e(route('user.profile.edit')); ?>"><i class="fas fa-user-edit"></i>Edit Profile</a>
                                                        </li>
                                                        <li>
                                                            <a href="<?php echo e(route('user.change.password')); ?>"><i class="fas fa-lock"></i>Change Password</a>
                                                        </li>
                                                        <li>
                                                            <a href="<?php echo e(route('user.logout')); ?>"><i class="fas fa-sign-out-alt"></i>Log Out</a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>


                        <?php echo $__env->yieldContent('content'); ?>

                        <div class="container-fluid sticky-bottom">
                            <div class="footer-bottom">
                                <div class="footer-bottom-area">
                                    <div >
                                        <p><?php echo e(__($gnl->copy_section)); ?></p>
                                    </div>
                                    <ul class="social-icons">
                                        <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="<?php echo e($social->url); ?>">
                                                <i class="<?php echo e($social->icon); ?>"></i>
                                            </a>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                    

                        <script src="<?php echo e(asset('assets/frontend/js/jquery-3.3.1.min.js')); ?>"></script>
                        <script src="<?php echo e(asset('assets/frontend/js/modernizr-3.6.0.min.js')); ?>"></script>
                        <script src="<?php echo e(asset('assets/frontend/js/plugins.js')); ?>"></script>
                        <script src="<?php echo e(asset('assets/frontend/js/bootstrap.min.js')); ?>"></script>
                        

                        <script src="<?php echo e(asset('assets/frontend/js/magnific-popup.min.js')); ?>"></script>
                        <script src="<?php echo e(asset('assets/frontend/js/jquery-ui.min.js')); ?>"></script>
                        <script src="<?php echo e(asset('assets/frontend/js/wow.min.js')); ?>"></script>
                        <script src="<?php echo e(asset('assets/frontend/js/odometer.min.js')); ?>"></script>
                        <script src="<?php echo e(asset('assets/frontend/js/viewport.jquery.js')); ?>"></script>
                        <script src="<?php echo e(asset('assets/frontend/js/nice-select.js')); ?>"></script>
                        <script src="<?php echo e(asset('assets/frontend/js/owl.min.js')); ?>"></script>
                        <script src="<?php echo e(asset('assets/frontend/js/paroller.js')); ?>"></script>
                        <script src="<?php echo e(asset('assets/frontend/js/chart.js')); ?>"></script>
                        <script src="<?php echo e(asset('assets/frontend/js/circle-progress.js')); ?>"></script>
                        <script src="<?php echo e(asset('assets/frontend/js/main.js')); ?>"></script>


                        
                        <script src="<?php echo e(asset('assets/frontend/bootstrap-notify-master/bootstrap-notify.js')); ?>"></script>
                        <script src="<?php echo e(asset('assets/frontend/bootstrap-notify-master/bootstrap-notify.min.js')); ?>}"></script>


                        <?php echo $__env->yieldPushContent('js'); ?>

                        <?php if(session()->has('success')): ?>
                            <script>
                                var content = {};

                                content.message = '<?php echo e(session('success')); ?>';
                                content.title = 'Success!!';
                                content.icon = 'fa fa-bell';

                                $.notify(content, {
                                    type: 'success',
                                    placement: {
                                        from: 'top',
                                        align: 'right'
                                    },

                                    time: 1000,
                                    delay: 4000,
                                });
                            </script>
                        <?php endif; ?>

                        <?php if(session()->has('warning')): ?>
                                <script>
                                    var content = {};

                                    content.message = '<?php echo e(session('warning')); ?>';
                                    content.title = 'Warning!!';
                                    content.icon = 'fa fa-bell';

                                    $.notify(content, {
                                        type: 'warning',
                                        placement: {
                                            from: 'top',
                                            align: 'right'
                                        },

                                        time: 1000,
                                        delay: 40000,
                                    });
                                </script>
                        <?php endif; ?>


                        <?php if($errors->any()): ?>
                            <script>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                var content = {};

                                content.message = '<?php echo e($error); ?>';
                                content.title = 'Error!!';
                                content.icon = 'fa fa-bell';

                                $.notify(content, {
                                    type: 'danger',
                                    placement: {
                                        from: 'top',
                                        align: 'right'
                                    },

                                    time: 500,
                                    delay: 4000,
                                });
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </script>
                        <?php endif; ?>

                        

                    </body>


                    <!-- Mirrored from pixner.net/hyipland/demo/dashboard.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 30 Sep 2023 12:11:00 GMT -->
                    </html>
<?php /**PATH F:\newproject\bank-fund-transfer\resources\views/users/master.blade.php ENDPATH**/ ?>