<?php $__env->startSection('content'); ?>


<section class="section">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">FAQ Update </h4>
        </div>

        <div class="card-body">
            <form action="<?php echo e(route('admin.faq.update',$faq->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
            <div class="row">

                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="basicInput" class="mb-2">Question</label>
                                <input type="text" name="qus" class="form-control form-control-lg" id="basicInput" value="<?php echo e($faq->question); ?>"  required>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group" class="mb-2">
                                <label for="basicInput">Answer</label>
                                <textarea type="text" cols="5" rows="5" class="form-control" id="basicInput" name="ans" required ><?php echo e($faq->answer); ?></textarea>
                            </div>
                        </div>


                <button type="submit" class="btn btn-success  me-1 mb-1">Submit</button>

            </form>

            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\newproject\bank-fund-transfer\resources\views/admin/pages/faq/edit.blade.php ENDPATH**/ ?>