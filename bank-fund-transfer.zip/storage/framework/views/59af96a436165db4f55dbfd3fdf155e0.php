<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">

                <div class="card-header">
                    <div class="card-title"><?php echo e($page_title); ?> Section</div>
                </div>
                <form  class="exampleValidation" action="<?php echo e(route('admin.settings.contact')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="card-body ">
                        <div class="row ">
                            <div class="form-group col-md-12 mb-4">
                                <label for="" class="mb-2"><?php echo app('translator')->get('Contact email'); ?> </label>
                                <input type="text" class="form-control form-control-lg" name="contact_email" value="<?php echo e($setting_extra->contact_email); ?>"
                                       placeholder="Enter service title">
                                <code><?php echo app('translator')->get('this email will use in contact form'); ?></code>
                            </div>

                            <div class="form-group col-md-12">
                                <label for="" class="mb-2"><?php echo app('translator')->get('Contact phone'); ?></label>
                                <input type="text" class="form-control form-control-lg" name="contact_phone" value="<?php echo e($setting_extra->contact_phone); ?>"
                                       placeholder="Enter service subtitle">
                                <code><?php echo app('translator')->get('this phone will use in header top'); ?></code>
                            </div>

                        </div>
                    </div>
                    <div class="card-footer pt-3">
                        <div class="col-12 text-center">
                            <button type="submit" class="btn btn-success btn-block">Update</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('button'); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\newproject\bank-fund-transfer\resources\views/admin/contact.blade.php ENDPATH**/ ?>