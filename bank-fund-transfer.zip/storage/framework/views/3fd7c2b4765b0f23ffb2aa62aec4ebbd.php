<?php $__env->startSection('content'); ?>

    <section id="basic-vertical-layouts">
        <div class="row match-height">
            <div class="col-md-4 col-12">
                <div class="card">
                    <div class="card-content">
                        <div class="card-body text-center">
                            <form class="form form-vertical">
                                <div class="form-body">
                                    <div class="row">
                                        <div class="col-12 ">
                                            <div class="avatar avatar-xl me-3 mb-3 ">
                                            <img src="<?php echo e(asset('assets/admin/images/profile/'.$admin->image)); ?>" alt="" srcset="">
                                            </div>

                                            <h3 class="card-title text-nowrap mb-1"> <?php echo e($admin->username); ?> </h3>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-8 col-12">
                <div class="card">
                    <div class="card-content">
                        <div class="card-body">
                            <form class="form form-vertical" action="<?php echo e(route('admin.profile.update')); ?>" method="POST" enctype="multipart/form-data" >
                                    <?php echo csrf_field(); ?>
                                <div class="form-body">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label for="first-name-vertical"> Name</label>
                                                <input type="text" id="first-name-vertical" class="form-control"
                                                name="name" value="<?php echo e($admin->name); ?>" required>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label for="email-id-vertical">Username</label>
                                                <input type="text" id="email-id-vertical" class="form-control"
                                                name="username" value="<?php echo e($admin->username); ?>" required>
                                            </div>
                                        </div>

                                        <div class="mb-3">
                                            <label for="formFileSm" class="form-label">Avatar </label>
                                            <input class="form-control form-control-sm" name="image" id="formFileSm" type="file">
                                        </div>

                                        <div class="col-12">
                                            <div class="form-group">
                                                <label for="email-id-vertical">Email</label>
                                                <input type="email" id="email-id-vertical" class="form-control"
                                                name="email" value="<?php echo e($admin->email); ?>" required >
                                            </div>
                                        </div>

                                            <button type="submit" class="btn btn-primary me-1 mb-1">Submit</button>

                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\newproject\bank-fund-transfer\resources\views/admin/admin_profile/index.blade.php ENDPATH**/ ?>