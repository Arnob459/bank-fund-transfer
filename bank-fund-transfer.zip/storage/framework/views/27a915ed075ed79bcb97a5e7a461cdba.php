<?php $__env->startSection('content'); ?>
<div class="row">

    <div class="col-xl-12">
        <div class="card">
            <div class="table-responsive">
                <table class="table table-lg">
                    <thead>
                        <tr>
                            <th><?php echo app('translator')->get('Short Code'); ?></th>
                            <th><?php echo app('translator')->get('Description'); ?></th>
                        </tr>
                    </thead>
                    <tbody class="list">
                        <tr>
                            <th>{{name}}</th>
                            <td><?php echo app('translator')->get('User Name'); ?></td>
                        </tr>
                        <tr>
                            <th>{{message}}</th>
                            <td><?php echo app('translator')->get('Message'); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-xl-12">
        <div class="card">
            <div class="card-header bg-primary">
                <h4 class="card-title font-weight-normal"><?php echo e($page_title); ?></h4>
            </div>
            <form action="<?php echo e(route('admin.email-template.global')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="form-row">

                        <div class="form-group col-md-12">
                            <label><?php echo app('translator')->get('Email Sent From'); ?> <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Email address" name="efrom" value="<?php echo e($general_setting->efrom); ?>"  required/>
                        </div>
                        <div class="form-group col-md-12">
                            <label><?php echo app('translator')->get('Email Body'); ?> <span class="text-danger">*</span></label>
                            <textarea name="etemp" id="myNicEditor" rows="10" class="form-control" placeholder="Your email template"><?php echo e($general_setting->etemp); ?></textarea>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <div class="form-group col-md-12 text-center">
                        <button type="submit" class="btn btn-block btn-primary mr-2"><?php echo app('translator')->get('Update'); ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startPush('nicEdit'); ?>
<script type="text/javascript" src="//js.nicedit.com/nicEdit-latest.js"></script>
<!-- Include NicEdit from a CDN -->


<script type="text/javascript">
    //<![CDATA[
    bkLib.onDomLoaded(function() {
        nicEditors.editors.push(
            new nicEditor().panelInstance(
                document.getElementById('myNicEditor')
            )
        );
    });
    //]]>
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\newproject\bank-fund-transfer\resources\views/admin/email_template/email_template.blade.php ENDPATH**/ ?>