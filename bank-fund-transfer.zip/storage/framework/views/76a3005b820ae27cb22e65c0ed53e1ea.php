<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"><?php echo e($page_title); ?>  </h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table  class="table  table-hover" >
                            <thead>
                            <tr>
                                <th scope="col">Date</th>
                                <th scope="col">Card Type </th>
                                <th scope="col">Username</th>
                                <th scope="col">Status</th>
                                <th scope="col">Details</th>
                                <th scope="col">Action</th>


                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(show_datetime($card->created_at)); ?></td>
                                    <td class="font-weight-bold"><?php echo e(strtoupper($card->cardType->name)); ?></td>
                                    <td><a href="<?php echo e(route('admin.user.edit', $card->user_id)); ?>"><?php echo e($card->user->username); ?></a></td>
                                    <td>
                                        <?php if($card->status == 0): ?>
                                            <span class="badge bg-warning"><?php echo app('translator')->get('Pending'); ?></span>
                                        <?php elseif($card->status == 1): ?>
                                            <span class="badge bg-success"><?php echo app('translator')->get('Approved'); ?></span>
                                        <?php elseif($card->status == 2): ?>
                                            <span class="badge bg-danger"><?php echo app('translator')->get('Rejected'); ?></span>
                                        <?php endif; ?>
                                    </td>

                                        <td>
                                            <button class="btn btn-primary "  data-bs-toggle="modal" data-bs-target="#primary<?php echo e($card->id); ?>"><i class="fa fa-fw fa-desktop"></i></button>
                                        </td>

                                            <!--Primary theme Modal -->
                                            <div class="modal fade text-left" id="primary<?php echo e($card->id); ?>" tabindex="-1" role="dialog"
                                            aria-labelledby="myModalLabel110" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable"
                                                role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header bg-primary">
                                                        <h5 class="modal-title white" id="myModalLabel110">Card Details
                                                        </h5>
                                                        <button type="button" class="close" data-bs-dismiss="modal"
                                                            aria-label="Close">
                                                            <i data-feather="x"></i>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">

                                                        <ul class="list-unstyled">
                                                            <li class="fw-500">Card Type</li>
                                                            <li class="text-muted"><?php echo e($card->cardType->name); ?></li>
                                                          </ul>



                                                          <ul class="list-unstyled">
                                                            <li class="fw-500">Card Number</li>
                                                            <li class="text-muted"><?php echo e($card->card_number); ?></li>
                                                          </ul>

                                                          <ul class="list-unstyled">
                                                            <li class="fw-500">Expiry Date</li>
                                                            <li class="text-muted"><?php echo e($card->expiry_date); ?></li>
                                                          </ul>


                                                          <ul class="list-unstyled">
                                                            <li class="fw-500">Name</li>
                                                            <li class="text-muted"><?php echo e($card->user->name); ?></li>
                                                          </ul>

                                                          <ul class="list-unstyled">
                                                            <li class="fw-500"> Card</li>
                                                            <?php if($card->type == 1): ?>
                                                            <li class="text-muted">Debit</li>

                                                            <?php else: ?>
                                                            <li class="text-muted">Credit</li>

                                                            <?php endif; ?>
                                                          </ul>



                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-light-secondary"
                                                            data-bs-dismiss="modal">
                                                            <i class="bx bx-x d-block d-sm-none"></i>
                                                            <span class="d-none d-sm-block">Close</span>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php if($card->status != 1): ?>

                                    <td>
                                        <button class="btn btn-success "  data-bs-toggle="modal" data-bs-target="#success<?php echo e($card->id); ?>"><i class="fa fa-fw fa-check"></i></button>
                                    </td>

                                            <!--Success theme Modal -->
                                            <div class="modal fade text-left" id="success<?php echo e($card->id); ?>" tabindex="-1" role="dialog"
                                                aria-labelledby="myModalLabel110" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable"
                                                    role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header bg-success">
                                                            <h5 class="modal-title white" id="myModalLabel110">Card Active
                                                            </h5>
                                                            <button type="button" class="close" data-bs-dismiss="modal"
                                                                aria-label="Close">
                                                                <i data-feather="x"></i>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">

                                                                 Are you sure you want to active this card
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-light-secondary"
                                                                data-bs-dismiss="modal">
                                                                <i class="bx bx-x d-block d-sm-none"></i>
                                                                <span class="d-none d-sm-block">Close</span>
                                                            </button>
                                                            <form method="POST" action="<?php echo e(route('admin.card.activate')); ?>">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="id" value="<?php echo e($card->id); ?>">
                                                            <button type="submit" class="btn btn-success ml-1">  <i class="bx bx-check d-block d-sm-none"></i> <span class="d-none d-sm-block">Active</span>
                                                            </button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php else: ?>

                                    <td>
                                        <button class="btn btn-danger "  data-bs-toggle="modal" data-bs-target="#danger<?php echo e($card->id); ?>"><i class="fa fa-fw fa-ban"></i></button>
                                    </td>

                                            <!--Success theme Modal -->
                                            <div class="modal fade text-left" id="danger<?php echo e($card->id); ?>" tabindex="-1" role="dialog"
                                                aria-labelledby="myModalLabel110" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable"
                                                    role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header bg-danger">
                                                            <h5 class="modal-title white" id="myModalLabel110">Card Inactive
                                                            </h5>
                                                            <button type="button" class="close" data-bs-dismiss="modal"
                                                                aria-label="Close">
                                                                <i data-feather="x"></i>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">

                                                                 Are you sure you want to inactive this card
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-light-secondary"
                                                                data-bs-dismiss="modal">
                                                                <i class="bx bx-x d-block d-sm-none"></i>
                                                                <span class="d-none d-sm-block">Close</span>
                                                            </button>
                                                            <form method="POST" action="<?php echo e(route('admin.card.deactivate')); ?>">
                                                                    <?php echo csrf_field(); ?>
                                                                    <input type="hidden" name="id" value="<?php echo e($card->id); ?>">
                                                                <button type="submit" class="btn btn-danger ml-1">  <i class="bx bx-check d-block d-sm-none"></i> <span class="d-none d-sm-block">Inactive</span>
                                                                </button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                    <?php endif; ?>
                                    <td></td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <ul class="pagination-overfollow">
                            <p><?php echo e($cards->appends(array_filter(Request::all()))->links( "pagination::bootstrap-5")); ?></p>
                        </ul>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\newproject\bank-fund-transfer\resources\views/admin/card/cards.blade.php ENDPATH**/ ?>