<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"><?php echo e($page_title); ?>  </h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table  class="table  table-hover" >
                            <thead>
                            <tr>
                                <th >Date</th>
                                <th >Trx Number</th>
                                <th >Sender</th>
                                <th >Receiver</th>
                                <th >Amount</th>
                                <th >Charge</th>
                                <th >After Charge</th>
                                <th >Payable</th>
                                <?php if(request()->routeIs('admin.ownbank.transfer.pending')): ?>
                                    <th >Action</th>
                                <?php elseif(request()->routeIs('admin.ownbank.transfer.log') || request()->routeIs('admin.ownbank.transfer.search')  || request()->routeIs('admin.ownbank.users.transfer')): ?>
                                    <th >Status</th>
                                <?php endif; ?>

                                <?php if(request()->routeIs('admin.ownbank.transfer.approved') || request()->routeIs('admin.ownbank.transfer.rejected')): ?>
                                    <th >Info</th>
                                <?php endif; ?>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $transfers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transfer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e(show_datetime($transfer->created_at)); ?></td>
                                    <td class="font-weight-bold"><?php echo e(strtoupper($transfer->trx)); ?></td>
                                    <td><a href="<?php echo e(route('admin.user.edit', $transfer->user_id)); ?>"><?php echo e($transfer->user->username); ?></a></td>
                                    <td><a href="<?php echo e(route('admin.user.edit', $transfer->receiver_id)); ?>"><?php echo e($transfer->receiver->username); ?></a></td>
                                    <td class="budget font-weight-bold"><?php echo e($transfer->amount +0); ?> <?php echo e($gnl->cur_sym); ?></td>
                                    <td class="budget text-danger"><?php echo e($gnl->cur_sym); ?> <?php echo e(formatter_money($transfer->charge)); ?></td>
                                    <td class="budget"><?php echo e($gnl->cur_sym); ?> <?php echo e(formatter_money($transfer->after_charge)); ?></td>

                                    <td class="budget font-weight-bold"><?php echo e(formatter_money($transfer->final_amount)); ?> <?php echo e($gnl->cur_sym); ?> </td>
                                    <?php if(request()->routeIs('admin.ownbank.transfer.pending')): ?>
                                        <td>


                                            <button class="btn btn-primary viewBtn" data-sender="<?php echo e($transfer->user->username); ?>" data-amount="<?php echo e(formatter_money($transfer->final_amount)); ?> <?php echo e($gnl->cur_sym); ?>" data-method="<?php echo e($transfer->receiver->username); ?>"><i class="fa fa-fw fa-desktop"></i></button>
                                            <button class="btn btn-success approveBtn"  data-id="<?php echo e($transfer->id); ?>" data-amount="<?php echo e(formatter_money($transfer->final_amount)); ?> <?php echo e($transfer->currency); ?>"><i class="fa fa-fw fa-check"></i></button>
                                            <button class="btn btn-danger rejectBtn" data-id="<?php echo e($transfer->id); ?>" data-amount="<?php echo e(formatter_money($transfer->final_amount)); ?> <?php echo e($transfer->currency); ?>"><i class="fa fa-fw fa-ban"></i></button>


                                        </td>
                                    <?php elseif(request()->routeIs('admin.ownbank.transfer.log') || request()->routeIs('admin.transfer.search') || request()->routeIs('admin.users.transfer')): ?>
                                        <td>
                                            <?php if($transfer->status == 2): ?>
                                                <span class="badge bg-warning"><?php echo app('translator')->get('Pending'); ?></span>
                                            <?php elseif($transfer->status == 1): ?>
                                                <span class="badge bg-success"><?php echo app('translator')->get('Approved'); ?></span>
                                            <?php elseif($transfer->status == 3): ?>
                                                <span class="badge bg-danger"><?php echo app('translator')->get('Rejected'); ?></span>
                                            <?php endif; ?>
                                        </td>
                                    <?php endif; ?>


                                    <?php if(request()->routeIs('admin.ownbank.transfer.approved') || request()->routeIs('admin.ownbank.transfer.rejected')): ?>

                                        <td>
                                            <button class="btn btn-primary detailsBtn" data-sender="<?php echo e($transfer->user->username); ?>" data-amount="<?php echo e(formatter_money($transfer->final_amount)); ?> <?php echo e($transfer->currency); ?>" data-method="<?php echo e($transfer->receiver->username); ?>" data-admin_details="<?php echo e($transfer->admin_feedback); ?>"><i class="fa fa-fw fa-desktop"></i></button>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-muted text-center" colspan="100%"><?php echo e($empty_message); ?></td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                        <ul class="pagination-overfollow">
                            <p><?php echo e($transfers->appends(array_filter(Request::all()))->links( "pagination::bootstrap-5")); ?></p>
                        </ul>

                    </div>
                </div>
            </div>
        </div>
    </div>



    
    <div id="detailsModal" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('View transfer Details'); ?></h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p> <span class="font-weight-bold transfer-sender"></span> wants to Send <span class="font-weight-bold transfer-amount">-</span> to <span class="font-weight-bold transfer-method">-</span> </p>

                    <p class="mt-3"> <?php echo app('translator')->get('ADMIN RESPONSE WAS'); ?>: <br> <span class="admin-detail"></span></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-warning" data-bs-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                </div>
            </div>
        </div>
    </div>

    
    <div id="viewModal" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('View transfer Information'); ?></h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p> <span class="font-weight-bold transfer-sender"></span> wants to Send <span class="font-weight-bold transfer-amount">-</span> to <span class="font-weight-bold transfer-method">-</span> </p>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-warning" data-bs-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                </div>
            </div>
        </div>
    </div>
    
    <div id="approveModal" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Approve transferal Confirmation'); ?></h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('admin.ownbank.transfer.approve')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id">
                    <div class="modal-body">
                        <p><?php echo app('translator')->get('Have you Sent '); ?><span class="font-weight-bold transfer-amount text-success"></span>?</p>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-warning" data-bs-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn btn-success"><?php echo app('translator')->get('Approve'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <div id="rejectModal" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Reject transferal Confirmation'); ?></h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('admin.ownbank.transfer.reject')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id">
                    <div class="modal-body">
                        <strong><?php echo app('translator')->get('Reason of Rejection'); ?></strong>
                        <textarea name="details" class="form-control pt-3" rows="3" placeholder="Provide the Details" required=""></textarea>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-warning" data-bs-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn btn-danger"><?php echo app('translator')->get('Reject'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $('.approveBtn').on('click', function() {
            var modal = $('#approveModal');
            modal.find('input[name=id]').val($(this).data('id'));
            modal.find('.transfer-amount').text($(this).data('amount'));
            modal.modal('show');
        });

        $('.rejectBtn').on('click', function() {
            var modal = $('#rejectModal');
            modal.find('input[name=id]').val($(this).data('id'));
            modal.find('.transfer-amount').text($(this).data('amount'));
            modal.modal('show');
        });

        $('.viewBtn').on('click', function() {
            var modal = $('#viewModal');
            modal.find('.transfer-amount').text($(this).data('amount'));
            modal.find('.transfer-method').text($(this).data('method'));
            modal.find('.transfer-sender').text($(this).data('sender'));



            modal.modal('show');
        });

        $('.detailsBtn').on('click', function() {
            var modal = $('#detailsModal');
            modal.find('.transfer-amount').text($(this).data('amount'));
            modal.find('.transfer-method').text($(this).data('method'));
            modal.find('.transfer-sender').text($(this).data('sender'));


            modal.find('.admin-detail').text($(this).data('admin_details'));
            modal.modal('show');
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\newproject\bank-fund-transfer\resources\views/admin/transfer/ownbank_transfers.blade.php ENDPATH**/ ?>