<?php $__env->startPush('button'); ?>
<button type="button" data-bs-toggle="modal"
data-bs-target="#createModal" class="btn btn-warning ">Add New Social Link</button>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">

            <div class="card">
                <div class="card-header">
                    <div class="card-title"><?php echo app('translator')->get('Social Links'); ?></div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-12">

                            <div class="table-responsive">
                                <table class="table table-lg table-hover mt-3">
                                    <thead>
                                    <tr>
                                        <th scope="col"><?php echo app('translator')->get('SL'); ?></th>
                                        <th scope="col"><?php echo app('translator')->get('Icon'); ?></th>
                                        <th scope="col"><?php echo app('translator')->get('URL'); ?></th>
                                        <th scope="col"><?php echo app('translator')->get('Actions'); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $icons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><i class="<?php echo e($social->icon); ?>"></i></td>
                                            <td><?php echo e($social->url); ?></td>
                                            <td>
                                                <a class="btn btn-secondary btn-sm"
                                                   href="<?php echo e(route('admin.settings.social.edit', $social->id)); ?>">
                                                    <span class="btn-label"><i class="fas fa-edit"></i></span>
                                                    <?php echo app('translator')->get('Edit'); ?></a>

                                                <button class="btn btn-danger btn-sm" data-bs-toggle="modal"
                                                        data-bs-target="#myModal-<?php echo e($social->id); ?>">
                                                    <span class="btn-label"><i class="fas fa-edit"></i></span>
                                                    <?php echo app('translator')->get('Delete'); ?>
                                                </button>

                                            </td>
                                        </tr>
                                        <div class="modal fade" id="myModal-<?php echo e($social->id); ?>">
                                            <div class="modal-dialog">
                                                <div class="modal-content" style="background-color: #202940;">
                                                    <!-- Modal Header -->
                                                    <div class="modal-header">
                                                        <h4 class="modal-title"><?php echo app('translator')->get("Are you sure?"); ?></h4>
                                                        <button type="button" class="close" data-bs-dismiss="modal">
                                                            &times;
                                                        </button>
                                                    </div>
                                                    <!-- Modal body -->
                                                    <div class="modal-body">
                                                        <?php echo app('translator')->get("You won't be able to revert this!"); ?>

                                                    </div>
                                                    <form class="d-inline-block" action="<?php echo e(route('admin.settings.social.destroy', $social->id)); ?>" method="post"><?php echo csrf_field(); ?><?php echo e(method_field('delete')); ?>

                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-danger"
                                                                    data-bs-dismiss="modal"><?php echo app('translator')->get('Close'); ?>
                                                            </button>
                                                            <button type="submit" class="btn btn-success"><?php echo app('translator')->get('Delete'); ?>
                                                            </button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<div class="modal fade text-left" id="createModal" tabindex="-1" role="dialog"
aria-labelledby="myModalLabel1" aria-hidden="true">
<div class="modal-dialog " role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="myModalLabel1">Add New Social Link </h5>
            <button type="button" class="close rounded-pill" data-bs-dismiss="modal"
                aria-label="Close">
                <i data-feather="x"></i>
            </button>
        </div>
        <form id="socialForm" action="<?php echo e(route('admin.settings.social.store')); ?>" method="post"  onsubmit="store(event)">
        <?php echo csrf_field(); ?>

        <div class="modal-body">

            <div class="col-md-12 ">
                <label for="basicInput"><?php echo app('translator')->get('Social Icon'); ?><span class="required-label">*</span></label>

                <div class="justify-content-center d-flex">
                    <div class="btn-group d-block">
                        <button type="button" class="btn btn-lg btn-secondary iconpicker-component"><i
                                class="fa fa-heart"></i>
                        </button>
                        <button  type="button" class="icp icp-dd btn btn-lg btn-secondary dropdown-toggle"
                                data-selected="fa-car" data-bs-toggle="dropdown">
                        </button>

                        <div class="dropdown-menu"></div>
                        <span class="action-create"></span>
                    </div>
                    <input id="inputIcon" type="hidden" name="icon">
                </div>
            </div>

                <div class="col-md-12">
                    <div class="form-group">
                        <label for="basicInput">URL<span class="required-label">*</span></label>
                        <input type="text" name="url" class="form-control form-control-lg"  placeholder="Enter URL of your social media account" required>
                    </div>
                </div>
        </div>
            <div class="modal-footer">
                <button type="button" class="btn" data-bs-dismiss="modal">
                    <i class="bx bx-x d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Close</span>
                </button>
                <button type="submit" class="btn btn-primary ml-1" >
                    <i class="bx bx-check d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Create</span>
                </button>
            </div>
        </form>
    </div>
</div>
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.iconpicker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\newproject\bank-fund-transfer\resources\views/admin/basic/social/index.blade.php ENDPATH**/ ?>