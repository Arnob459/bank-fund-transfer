<?php $__env->startSection('content'); ?>

<?php $__env->startPush('button'); ?>
<a href="<?php echo e(route('admin.choose.create')); ?>" class="btn btn-warning ">Add New</a>
<?php $__env->stopPush(); ?>

<section class="section">
    <div class="card ">
        <div class="card-header">
            <h4 class="card-title">Why Choose Us </h4>
        </div>

        <div class="card-body">
            <form action="<?php echo e(route('admin.choosesection.update')); ?>" method="post" >
                <?php echo csrf_field(); ?>
            <div class="row">

                <div class="col-md-4 mb-3">
                    <div class="form-group">
                        <label for="basicInput" class="mb-2"> Title</label>
                        <input type="text" name="choose_title" class="form-control form-control-lg" id="basicInput" value="<?php echo e($choose->title); ?>"  required>
                    </div>
                </div>

                <div class="col-md-8">
                    <div class="form-group">
                        <label for="basicInput" class="mb-2"> Subtitle</label>
                        <input type="text" name="choose_subtitle" class="form-control form-control-lg" id="basicInput" value="<?php echo e($choose->sub_title?? ''); ?>"   placeholder="Enter Choose us subtitle"  >
                    </div>
                </div>
                <hr>

                <button type="submit" class="btn btn-success me-1 mb-1">Submit</button>

            </form>

            </div>
        </div>
    </section>

    <section class="section">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Why Choose Us </h4>
            </div>

            <div class="card-body">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-lg">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Icon</th>
                                    <th>Title</th>
                                    <th>Short Text</th>
                                    <th>Actions</th>


                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $chooses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td class="text-bold-500">
                                        <i class="<?php echo e($item->icon); ?>"></i>
                                    </td>
                                    <td class="text-bold-500"><?php echo e($item->title); ?></td>
                                    <td class="text-bold-500"><?php echo e($item->short_text); ?></td>
                                    <td>
                                        <a  href="<?php echo e(route('admin.choose.edit',$item->id)); ?>"  class="btn btn-primary rounded-pill"  ><i class ="bi bi-pencil">Edit</i></a>
                                        <button type="button" class="btn btn-danger rounded-pill" data-toggle="modal" data-target="#deleteModal<?php echo e($item->id); ?>"><i class ="fa fa-trash"></i>Delete</button>
                                    </td>

                                </tr>
                                
                                        <div class="modal fade" id="deleteModal<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel<?php echo e($item->id); ?>" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="deleteModalLabel<?php echo e($item->id); ?>">Are You sure?</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        Are you sure you want to delete this item?
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                        <form method="POST" action="<?php echo e(route('admin.choose.destroy', $item->id)); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-danger">Delete</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>


                </div>
            </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('assets/admin/js/jquery-3.6.0.min.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\newproject\bank-fund-transfer\resources\views/admin/pages/choose/index.blade.php ENDPATH**/ ?>