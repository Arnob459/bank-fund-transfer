<?php $__env->startSection('content'); ?>
    <div class="row ">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-head-row">
                        <h4 class="card-title"><?php echo e($page_title); ?></h4>
                    </div>
                </div>
                <form id="exampleValidation" method="post" action="<?php echo e(route('admin.banks.update', $bank->id)); ?>"
                      enctype="multipart/form-data">
                    <div class="card-body">
                        <div class="row">
                            <?php echo csrf_field(); ?>
                            <div class="col-md-3">
                                <div class="form-group ">
                                    <label class="col-lg-6 col-md-3 col-sm-4 mt-sm-2"><?php echo app('translator')->get('Upload Image'); ?> <span
                                            class="required-label">*</span></label>
                                    <div class="col-lg-12">
                                        <div class="input-file input-file-image">
                                            <div class="form-group ">
                                                <img  class="img-fluid" id="image-preview"
                                                src="<?php echo e(asset('assets/images/banks/'.$bank->image)); ?>" alt="preview">
                                            </div>
                                            <div class="col-lg-12 ">
                                                <div class="input-file input-file-image">
                                                    <input type="file" class="form-control " id="image" name="image" accept="image/*" hidden >
                                                    <label for="image" class="btn btn-primary rounded-pill "><i class="fa fa-file-image"></i> Upload</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <p class="text-warning mb-0 mt-2"><?php echo app('translator')->get('Image Will Resize 200x200'); ?>.</p>
                                    <p class="text-warning mb-0"><?php echo app('translator')->get('Only jpg, jpeg, png image allowed'); ?>.</p>
                                </div>
                            </div>
                            <div class="col-md-9">
                                <div class="row " >
                                    <div class="form-group col-md-12 mb-3">
                                        <label for="name"><?php echo app('translator')->get('Bank Name'); ?></label>
                                        <input type="text" class="form-control " placeholder="Bank Name" name="name"
                                               value="<?php echo e($bank->name); ?>" required/>
                                    </div>
                                    <div class="form-group col-md-6 mb-3">
                                        <label for="name"><?php echo app('translator')->get('Routing Number'); ?></label>
                                        <input type="text" class="form-control " placeholder="Routing Number" name="routing_number"
                                               value="<?php echo e($bank->routing_number); ?>" required/>
                                    </div>
                                    
                                    
                                    <div class="form-group col-md-6 mb-3">
                                        <label for="name"> <?php echo app('translator')->get('Processing time'); ?> <span class="text-danger">*</span></label>
                                        <input type="text" name="processing_time" placeholder="Processing time"
                                               class="form-control form-control border-radius-5"
                                               value="<?php echo e($bank->processing_time); ?>" required/></div>
                                    </div>
                                <hr>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label><?php echo app('translator')->get('Minimum Transfer Amount'); ?> <span class="text-danger">*</span></label>
                                            <div class="input-group mb-3">
                                                <input type="text" class="form-control" name="minimum_limit" placeholder="0"
                                                       value="<?php echo e(formatter_money($bank->minimum_limit)); ?>" required/>
                                                       <div class="input-group-append">
                                                        <div class="input-group-text"><?php echo e($gnl->cur); ?></div>
                                                    </div>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label><?php echo app('translator')->get('Maximum Transfer Amount'); ?> <span class="text-danger">*</span></label>
                                            <div class="input-group">
                                                <input type="text" class="form-control" placeholder="0" name="maximum_limit"
                                                       value="<?php echo e(formatter_money($bank->maximum_limit)); ?>" required/>
                                                <div class="input-group-append">
                                                    <div class="input-group-text"><?php echo e($gnl->cur); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label><?php echo app('translator')->get('Bank Fixed Charge'); ?> <span class="text-danger">*</span></label>
                                            <div class="input-group mb-3">
                                                <input type="text" class="form-control" placeholder="0"
                                                       name="fixed_charge"
                                                       value="<?php echo e(formatter_money($bank->fixed_charge)); ?>" required/>
                                                <div class="input-group-append">
                                                    <div class="input-group-text"><?php echo e($gnl->cur); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label><?php echo app('translator')->get('Bank Percent Charge'); ?> <span class="text-danger">*</span></label>
                                        <div class="input-group">
                                            <input type="text" class="form-control" placeholder="0"
                                                       name="percent_charge" value="<?php echo e($bank->percent_charge); ?>"
                                                       required>
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">%</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                        <br>
                        <?php if($bank->primary == 0): ?>
                        <div class="row">

                            <div class="col-lg-12">
                                <div class="card outline-dark">
                                    <div class="card-header  d-flex justify-content-between">
                                        <h5>User Account Information</h5>
                                        <button type="button" class="btn btn-sm btn-outline-light addUserData"><i
                                                class="fa fa-fw fa-plus"></i><?php echo app('translator')->get('Add New'); ?>
                                        </button>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-row" id="userData">
                                            <?php $__currentLoopData = json_decode($bank->user_data); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <div class="col-md-4 user-data mt-2">
                                                        <div class="input-group has_append">
                                                            <input type="text"
                                                                   class="form-control border-radius-5"
                                                                   name="ud[]" value="<?php echo e($data); ?>" required>
                                                            <div class="input-group-append">
                                                                <button type="button"
                                                                        class="btn btn-danger removeBtn"><i
                                                                        class="bi bi-x"></i></button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>

                        <div class="card-action">
                            <button class="btn btn-success btn-block"><?php echo app('translator')->get('Submit'); ?></button>
                        </div>

                    </div>
                </form>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.validation_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $('input[name=currency]').on('input', function () {
            $('.currency_symbol').text($(this).val());
        });
        $('.addUserData').on('click', function () {
            var html = `<div class="col-md-4 user-data mt-2">

                    <div class="input-group has_append">
                        <input class="form-control border-radius-5" name="ud[]" required>
                        <div class="input-group-append">
                            <button type="button" class="btn btn-danger  removeBtn"><i class="bi bi-x"></i></button>
                        </div>

                    </div>
                </div>`;

            $('#userData').append(html);
        });
        $(document).on('click', '.removeBtn', function () {
            $(this).parents('.user-data').remove();
        });
        <?php if(old('currency')): ?>
        $('input[name=currency]').trigger('input');
        <?php endif; ?>
    </script>
<?php $__env->stopPush(); ?>



<?php $__env->startPush('js'); ?>
<script>
    function previewImage(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function(e) {
                $('#image-preview').attr('src', e.target.result).show();
            };

            reader.readAsDataURL(input.files[0]);
        }
    }

    $('#image').on('change', function() {
        previewImage(this);
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\newproject\bank-fund-transfer\resources\views/admin/bank/edit.blade.php ENDPATH**/ ?>