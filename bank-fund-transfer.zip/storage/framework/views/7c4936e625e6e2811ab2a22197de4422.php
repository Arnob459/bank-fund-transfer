<?php $__env->startSection('content'); ?>
        <div class="dashboard-inner-content">
            <div class="card">
                <h5 class="card-header"><?php echo e($page_title); ?></h5>
                <div class="card-body">
                    <form action="<?php echo e(route('user.ownbank.requestmoney.submit')); ?>" method="post">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" class="fixed_charge" value="<?php echo e(formatter_money($gnl->fixed_charge)); ?>">
                        <input type="hidden" id="percent_charge" value="<?php echo e($gnl->percent_charge+0); ?>">

                        <div class="row">
                            <div class="col-xl-6 col-lg-6">
                                <label for="a-trans">Request Amount</label>
                                <input type="text" class="amount" name="amount" placeholder="enter amount"
                                       onkeyup="this.value = this.value.replace (/^\.|[^\d\.]/g, '')" required>
                            </div>

                            <div class="col-xl-6 col-lg-6">
                                <label for="username">Request Username</label>
                                <input type="text" id="username" name="username" placeholder="enter username"  required>
                                <div>
                                    <ul id="search-results"></ul>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6">
                            <div class="check_box_group">
                                <input class="radioButton" type="radio" name="who" id="sender" value="1" checked >
                                <label class="check_boxes-label" for="sender">I will pay the charge</label>
                              </div>

                              <div class="check_box_group">
                                <input class="radioButton" type="radio" name="who" id="receiver" value="0">
                                <label class="check_boxes-label" for="receiver">Receiver will pay the charge</label>
                              </div>
                            </div>




                            <div class="col-xl-6 col-lg-6">
                                <label
                                    for="charge"><?php echo app('translator')->get('Charge'); ?>: <?php echo e(formatter_money($gnl->fixed_charge)); ?> <?php echo e($gnl->cur); ?>

                                    + <?php echo e($gnl->percent_charge+0); ?> %</label>
                                <input type="text" readonly="readonly" value="0" id="charge">
                            </div>
                            <div class="col-xl-6 col-lg-6">
                                <label for="payAmount"><?php echo app('translator')->get('Amount After Charge'); ?> : <?php echo e($gnl->cur); ?></label>
                                <input type="text" value="0" id="payAmount" readonly="readonly">
                            </div>


                            <div class="col-xl-12 col-lg-12">
                                <label id="balance_limit_label"><?php echo app('translator')->get('Your Balance Will Be'); ?> : <?php echo e($gnl->cur); ?> </label>
                                <input type="text" value="<?php echo e(formatter_money(auth()->user()->balance)); ?>"
                                       id="afterBalance" readonly="readonly">
                            </div>
                        </div>

                        <div class="col-xl-12 col-lg-12 col-md-12 text-center">
                            <button class="btn btn-warning" id="myBtn" type="submit">Send</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(function () {
            $('.amount').keyup(function () {

                var amount = parseFloat($('.amount').val()) || 0;

                var balance = parseFloat(<?php echo e(formatter_money(auth()->user()->balance)); ?>) || 0;
                var fix_charge = parseFloat($('.fixed_charge').val()) || 0;
                var percent_charge = parseFloat($('#percent_charge').val()) || 0;

                var isRadioButtonChecked = $('.radioButton:checked').val() === '1';

            if (isRadioButtonChecked) {

                var percent = (amount * percent_charge / 100);
                var charge = fix_charge + percent;
                var payAmount = amount - charge;
                var afterBalance = balance + payAmount;
                $('#charge').val(charge.toFixed(2));
                $('#payAmount').val(payAmount.toFixed(2));
                $('#afterBalance').val(afterBalance.toFixed(2));



            } else {
                var percent = (amount * percent_charge / 100);
                var charge = fix_charge + percent;
                var payAmount = amount - charge;
                var afterBalance = balance + amount;
                $('#charge').val(charge.toFixed(2));
                $('#payAmount').val(payAmount.toFixed(2));
                $('#afterBalance').val(afterBalance.toFixed(2));
            }


            });
        });
    </script>

    <script>
        $(document).ready(function () {
            $('#username').on('keyup', function () {
                var query = $(this).val().trim();
                console.log(query);
                if (query !== '') {
                    $.ajax({
                        url: "<?php echo e(route('checkusername')); ?>",
                        type: 'GET',
                        data: { query: query },
                        success: function (data) {




                    if (data.username == query ){
                         $("#search-results").html(data.name);
                    }
                    else{
                        $("#search-results").html(data.status);
                    }
                   //  console.log(data.id);

                    }

                    });
                }
            });
        });
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('users.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\newproject\bank-fund-transfer\resources\views/users/own_bank/request_money.blade.php ENDPATH**/ ?>