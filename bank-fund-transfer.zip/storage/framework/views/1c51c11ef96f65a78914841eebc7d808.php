<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-title"><?php echo e($page_title); ?></div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-lg">
                            <thead>
                            <tr>
                                <th><?php echo app('translator')->get('Short Code'); ?></th>
                                <th><?php echo app('translator')->get('Description'); ?></th>
                            </tr>
                            </thead>
                            <tbody class="list">
                            <?php $__empty_1 = true; $__currentLoopData = $email_template->shortcodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shortcode => $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <th><?php echo "{{". $shortcode ."}}"  ?></th>
                                    <td><?php echo e($key); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="100%" class="text-muted text-center"><?php echo app('translator')->get('No short code available'); ?></td></tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>


<div class="row">
    <div class="col-xl-12">
        <div class="card">
            <div class="card-header bg-primary">
                <h4 class="card-title font-weight-normal"><?php echo e($page_title); ?></h4>
            </div>
            <form action="<?php echo e(route('admin.email-template.update', $email_template->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="form-row">

                        <div class="form-group col-md-12">
                            <label><?php echo app('translator')->get('Subject'); ?> <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Email subject" name="subject" value="<?php echo e($email_template->subj); ?>" />
                        </div>
                        <div class="form-group col-md-4">
                            <label><?php echo app('translator')->get('Status'); ?> <span class="text-danger">*</span></label>

                            <input type="checkbox" data-height="46px" data-width="100%" data-onstyle="success" data-offstyle="danger" data-toggle="toggle" data-on="Send Email" data-off="Don't Send" name="email_status" <?php if($email_template->email_status): ?> checked <?php endif; ?>>
                        </div>
                        <div class="form-group col-md-12">
                            <label><?php echo app('translator')->get('Message'); ?> <span class="text-danger">*</span></label>
                            <textarea name="email_body" rows="10" id="myNicEditor" class="form-control" placeholder="Your message using shortcodes"><?php echo e($email_template->email_body); ?></textarea>
                        </div>

                    </div>
                </div>
                <div class="card-footer">
                    <div class="form-group col-md-12">
                        <button type="submit" class="btn btn-block btn-primary mr-2"><?php echo app('translator')->get('Submit'); ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('nicEdit'); ?>
<script type="text/javascript" src="//js.nicedit.com/nicEdit-latest.js"></script>
<!-- Include NicEdit from a CDN -->


<script type="text/javascript">
    //<![CDATA[
    bkLib.onDomLoaded(function() {
        nicEditors.editors.push(
            new nicEditor().panelInstance(
                document.getElementById('myNicEditor')
            )
        );
    });
    //]]>
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\newproject\bank-fund-transfer\resources\views/admin/email_template/edit.blade.php ENDPATH**/ ?>