<?php $__env->startSection('content'); ?>

<?php $__env->startPush('button'); ?>
<a href="<?php echo e(route('admin.slider.create')); ?>" class="btn btn-lg btn-warning ">Add New</a>
<?php $__env->stopPush(); ?>

<section class="section">

    <div class="row">
        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-xl-4 col-md-6 col-sm-12">
            <div class="card">
                <div class="card-content">
                    <div class="card-body">

                    <img class="img-fluid w-100" src="<?php echo e(asset('assets/images/slider/'.$slider->image)); ?>" id="image-preview" alt="Slider Image">

                    </div>
                </div>
                <hr>

                <div class="card-footer ">
                    <h4 class="card-title"> <?php echo e($slider->title); ?></h4>
                    <p> <?php echo e($slider->subtitle); ?> </p>
                    <a type="submit"  href="<?php echo e(route('admin.slider.edit',$slider->id)); ?>"  class="btn btn-primary rounded-pill"  ><i class ="bi bi-pencil">Edit</i></a>
                    <button type="button" class="btn btn-danger rounded-pill" data-toggle="modal" data-target="#deleteModal<?php echo e($slider->id); ?>"><i class ="fa fa-trash"></i>Delete</button>
                </div>
            </div>
        </div>
         
         <div class="modal fade" id="deleteModal<?php echo e($slider->id); ?>" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel<?php echo e($slider->id); ?>" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLabel<?php echo e($slider->id); ?>">Are you sure?</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        Are you sure you want to delete this item?
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <form method="POST" action="<?php echo e(route('admin.slider.destroy', $slider->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>




</section>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('assets/admin/js/jquery-3.6.0.min.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\newproject\bank-fund-transfer\resources\views/admin/pages/slider/index.blade.php ENDPATH**/ ?>