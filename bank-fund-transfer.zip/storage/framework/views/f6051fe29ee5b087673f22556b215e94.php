    <?php $__env->startPush('button'); ?>
    <a href="<?php echo e(route('admin.card.type.create')); ?>" class="btn btn-warning ">Add New Card type</a>
    <?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"><?php echo e($page_title); ?>  </h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table  class="table  table-hover" >
                            <thead>
                            <tr>
                                <th >SL</th>
                                <th >Image </th>
                                <th >Name</th>
                                <th >Status</th>
                                <th >Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $card_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td class="text-bold-500">
                                        <img  src="<?php echo e(asset('assets/images/card/'.$type->image)); ?>" >
                                    </td>
                                    <td class="font-weight-bold"><?php echo e($type->name); ?></td>


                                    <td>
                                        <?php if($type->status == 0): ?>
                                            <span class="badge bg-warning"><?php echo app('translator')->get('Pending'); ?></span>
                                        <?php elseif($type->status == 1): ?>
                                            <span class="badge bg-success"><?php echo app('translator')->get('Active'); ?></span>
                                        <?php elseif($type->status == 2): ?>
                                            <span class="badge bg-danger"><?php echo app('translator')->get('Deactive'); ?></span>
                                        <?php endif; ?>
                                    </td>


                                    <?php if($type->status != 1): ?>

                                    <td>
                                        <button class="btn btn-success "  data-bs-toggle="modal" data-bs-target="#success<?php echo e($type->id); ?>"><i class="fa fa-fw fa-check"></i></button>
                                    </td>

                                            <!--Success theme Modal -->
                                            <div class="modal fade text-left" id="success<?php echo e($type->id); ?>" tabindex="-1" role="dialog"
                                                aria-labelledby="myModalLabel110" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable"
                                                    role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header bg-success">
                                                            <h5 class="modal-title white" id="myModalLabel110">Card type Active
                                                            </h5>
                                                            <button type="button" class="close" data-bs-dismiss="modal"
                                                                aria-label="Close">
                                                                <i data-feather="x"></i>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">

                                                                 Are you sure you want to active this Card type
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-light-secondary"
                                                                data-bs-dismiss="modal">
                                                                <i class="bx bx-x d-block d-sm-none"></i>
                                                                <span class="d-none d-sm-block">Close</span>
                                                            </button>
                                                            <form method="POST" action="<?php echo e(route('admin.type.activate')); ?>">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="id" value="<?php echo e($type->id); ?>">
                                                            <button type="submit" class="btn btn-success ml-1">  <i class="bx bx-check d-block d-sm-none"></i> <span class="d-none d-sm-block">Active</span>
                                                            </button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php else: ?>

                                    <td>
                                        <button class="btn btn-danger "  data-bs-toggle="modal" data-bs-target="#danger<?php echo e($type->id); ?>"><i class="fa fa-fw fa-ban"></i></button>
                                    </td>

                                            <!--Success theme Modal -->
                                            <div class="modal fade text-left" id="danger<?php echo e($type->id); ?>" tabindex="-1" role="dialog"
                                                aria-labelledby="myModalLabel110" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable"
                                                    role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header bg-danger">
                                                            <h5 class="modal-title white" id="myModalLabel110">Card type Inactive
                                                            </h5>
                                                            <button type="button" class="close" data-bs-dismiss="modal"
                                                                aria-label="Close">
                                                                <i data-feather="x"></i>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">

                                                                 Are you sure you want to inactive this Card type
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-light-secondary"
                                                                data-bs-dismiss="modal">
                                                                <i class="bx bx-x d-block d-sm-none"></i>
                                                                <span class="d-none d-sm-block">Close</span>
                                                            </button>
                                                            <form method="POST" action="<?php echo e(route('admin.card.type.deactivate')); ?>">
                                                                    <?php echo csrf_field(); ?>
                                                                    <input type="hidden" name="id" value="<?php echo e($type->id); ?>">
                                                                <button type="submit" class="btn btn-danger ml-1">  <i class="bx bx-check d-block d-sm-none"></i> <span class="d-none d-sm-block">Inactive</span>
                                                                </button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                    <?php endif; ?>
                                    <td></td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <ul class="pagination-overfollow">
                            <p><?php echo e($card_types->appends(array_filter(Request::all()))->links( "pagination::bootstrap-5")); ?></p>
                        </ul>

                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\newproject\bank-fund-transfer\resources\views/admin/card/card_types.blade.php ENDPATH**/ ?>