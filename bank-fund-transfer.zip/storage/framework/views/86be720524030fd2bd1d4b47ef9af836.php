<?php $__env->startSection('content'); ?>
<!-- Content
  ============================================= -->
  <div id="content" class="py-4">
    <div class="container">
      <div class="row">

        <!-- Left Panel
        ============================================= -->
        <aside class="col-lg-3">

            <!-- Profile Details
            =============================== -->
            <div class="bg-white shadow-sm rounded text-center p-3 mb-4">
              <div class="profile-thumb mt-3 mb-4"> <img class="rounded-circle" src="https://harnishdesign.net/demo/html/payyed/images/profile-thumb.jpg" alt="">
                <div class="profile-thumb-edit bg-primary text-white" data-bs-toggle="tooltip" title="Change Profile Picture"> <i class="fas fa-camera position-absolute"></i>
                  <input type="file" class="custom-file-input" id="customFile">
                </div>
              </div>
              <p class="text-3 fw-500 mb-2">Hello, <?php echo e(auth()->user()->username); ?></p>
              <p class="mb-2"><a href="<?php echo e(route('user.profile')); ?>" class="text-5 text-light" data-bs-toggle="tooltip" title="Edit Profile"><i class="fas fa-edit"></i></a></p>
            </div>
            <!-- Profile Details End -->

            <!-- Available Balance
            =============================== -->
            <div class="bg-white shadow-sm rounded text-center p-3 mb-4">
              <div class="text-17 text-light my-3"><i class="fas fa-wallet"></i></div>
              <h3 class="text-9 fw-400"><?php echo e($gnl->cur_sym); ?> <?php echo e(formatter_money(auth()->user()->balance)); ?> </h3>
              <p class="mb-2 text-muted opacity-8">Available Balance</p>
            </div>
            <!-- Available Balance End -->

            <!-- Need Help?
            =============================== -->
            <div class="bg-white shadow-sm rounded text-center p-3 mb-4">
              <div class="text-17 text-light my-3"><i class="fas fa-comments"></i></div>
              <h3 class="text-5 fw-400 my-4">Need Help?</h3>
              <p class="text-muted opacity-8 mb-4">Have questions or concerns regrading your account?<br>
                Our experts are here to help!.</p>
              <div class="d-grid"><a href="#" class="btn btn-primary">Chate with Us</a></div>
            </div>
            <!-- Need Help? End -->

          </aside>
        <!-- Left Panel End -->

        <!-- Middle Panel
        ============================================= -->
        <div class="col-lg-9">

          <!-- Personal Details
          ============================================= -->
          <div class="bg-white shadow-sm rounded p-4 mb-4">
            <h3 class="text-5 fw-400 d-flex align-items-center mb-4">Personal Details<a href="#edit-personal-details" data-bs-toggle="modal" class="ms-auto text-2 text-uppercase btn-link"><span class="me-1"><i class="fas fa-edit"></i></span>Edit</a></h3>
            <hr class="mx-n4 mb-4">
            <div class="row gx-3 align-items-center">
              <p class="col-sm-3 text-muted text-sm-end mb-0 mb-sm-3">Name:</p>
              <p class="col-sm-9 text-3"><?php echo e($user->name); ?></p>
            </div>
            <div class="row gx-3 align-items-center">
                <p class="col-sm-3 text-muted text-sm-end mb-0 mb-sm-3">Username:</p>
                <p class="col-sm-9 text-3"><?php echo e($user->username); ?></p>
              </div>

            <div class="row gx-3 align-items-baseline">
              <p class="col-sm-3 text-muted text-sm-end mb-0 mb-sm-3">Address:</p>
              <p class="col-sm-9 text-3"><?php echo e($user->address->address?? 'N/A'); ?><br>

                <?php echo e($user->address->city?? ''); ?><br>
                <?php echo e($user->address->state?? ''); ?>,<?php echo e($user->address->zip?? ''); ?><br>
                <?php echo e($user->address->country?? ''); ?></p>
            </div>
          </div>
          <!-- Edit Details Modal
          ================================== -->
          <div id="edit-personal-details" class="modal fade " role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title fw-400">Personal Details</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-4">
                  <form id="personaldetails" action="<?php echo e(route('user.profile.update')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                        <?php echo e(method_field('put')); ?>


                    <div class="row g-3">
                      <div class="col-12 col-sm-12">
                        <label for="firstName" class="form-label">Full Name</label>
                        <input type="text" value="<?php echo e($user->name); ?>" name="name" class="form-control" data-bv-field="firstName" id="firstName" required placeholder="Full Name">
                      </div>
                      <div class="col-12 col-sm-12">
                        <label for="username" class="form-label">username</label>
                        <input type="text" value="<?php echo e($user->username); ?>"  class="form-control" data-bv-field="username" id="username" readonly placeholder="username">
                      </div>


					  </div>

                      <h3 class="text-5 fw-400 mt-4">Address</h3>
                      <hr>
                      <div class="row g-3">
					  <div class="col-12">
                        <label for="address" class="form-label">Address</label>
                        <input type="text" value="<?php echo e($user->address->address); ?>" name="address" class="form-control" data-bv-field="address" id="address" required placeholder="Address 1">
                      </div>
                      <div class="col-12 col-sm-6">
                        <label for="state" class="form-label">State</label>
                        <input id="state" value="<?php echo e($user->address->state); ?>" name="state" type="text" class="form-control" required placeholder="state">
                    </div>
                      <div class="col-12 col-sm-6">
                          <label for="city" class="form-label">City</label>
                          <input id="city" value="<?php echo e($user->address->city); ?>" name="city" type="text" class="form-control" required placeholder="City">
                      </div>

                      <div class="col-12 col-sm-6">
                        <label for="zipCode" class="form-label">Zip Code</label>
                        <input id="zipCode" value="<?php echo e($user->address->zip); ?>" name="zip" type="text" class="form-control" required placeholder="zip">
                      </div>
                      <div class="col-12 col-sm-6">
                          <label for="inputCountry" class="form-label">Country</label>
                          <select class="form-select" name="country" id="inputCountry" name="country_id">
                            <?php echo $__env->make('partials.country', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                          </select>
                      </div>
					  <div class="col-12 mt-4 d-grid"><button class="btn btn-primary" type="submit">Save Changes</button></div>
                    </div>

                  </form>
                </div>
              </div>
            </div>
          </div>
          <!-- Personal Details End -->





        </div>
        <!-- Middle Panel End -->
      </div>
    </div>
  </div>
  <!-- Content end -->


<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        $("select[name=country]").val("<?php echo e(auth()->user()->address->country); ?>");
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\newproject\bank-fund-transfer\resources\views/user/profile/kyc.blade.php ENDPATH**/ ?>