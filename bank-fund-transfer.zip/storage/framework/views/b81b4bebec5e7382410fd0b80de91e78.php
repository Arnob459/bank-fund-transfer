
    <!--============= Sign In Section Starts Here =============-->
    <div class="account-section bg_img" data-background="<?php echo e(asset('assets/frontend/images/account-bg.jpg')); ?>">
        <div class="container">
            <div class="account-title text-center">
                <a href="<?php echo e(route('index')); ?>" class="back-home nav-link"><i class="fas fa-angle-left"></i><span>Back <span class="d-none d-sm-inline-block">To <?php echo e($gnl->site_name); ?></span></span></a>
                <a href="<?php echo e(route('index')); ?>" class="logo">
                    <img src="<?php echo e(asset('assets/images/logo/'. $gnl->favicon )); ?>" alt="logo">
                </a>
            </div>
            <div class="account-title text-center">
                <h4 class="text-white"><?php echo e($page_title); ?></h4>
            </div>
            <div class="account-wrapper">
                <div class="account-body">
                    <h4 class="title mb-20">Verify your account</h4>
                    <?php if(!$user->email_verify): ?>
                    <form class="account-form" action="<?php echo e(route('user.verify_email')); ?>" method="post" id="recaptchaForm">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="form-group">
                                <input type="text" class="form-control" name="email_verified_code" placeholder="<?php echo app('translator')->get('Email verification'); ?>">
                            </div>
                            <div class=" form-group text-center">
                                <button type="submit" id="recaptcha" class="mt-2 mb-2"><?php echo app('translator')->get('Verify Code'); ?></button>
                            </div>
                            <div class="form-group ">
                                <p><a class="nav-link" href="<?php echo e(route('user.send_verify_code')); ?>?type=email"><?php echo app('translator')->get('Send Email Code'); ?></a></p>
                            </div>
                        </div>
                    </form>

                <?php elseif(!$user->sms_verify): ?>
                    <form class="account-form" action="<?php echo e(route('user.verify_sms')); ?>" method="post" id="recaptchaForm">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="form-group">
                                <input type="text" name="sms_verified_code" placeholder="<?php echo app('translator')->get('SMS verification'); ?>" >
                            </div>
                            <div class="form-group text-center">
                                <button type="submit" id="recaptcha"  class="mt-2 mb-2"><?php echo app('translator')->get('Verify Code'); ?></button>
                            </div>

                            <div class="form-group">
                                <p><a class="nav-link" href="<?php echo e(route('user.send_verify_code')); ?>?type=phone"><?php echo app('translator')->get('Send Verification Code'); ?></a></p>
                            </div>
                        </div>
                    </form>

                <?php elseif(!$user->tv): ?>
                    <form class="account-form" action="<?php echo e(route('user.go2fa.verify')); ?>" method="POST" id="recaptchaForm">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="form-group">
                                <input type="text" name="code" id="pincode-input">
                            </div>

                            <div class="form-group text-center">
                                <button type="submit" id="recaptcha" class="mt-2 mb-2"><?php echo app('translator')->get('Verify Code'); ?></button>
                            </div>
                        </div>
                    </form>
                <?php endif; ?>
                </div>

            </div>
        </div>
    </div>
<?php /**PATH F:\newproject\bank-fund-transfer\resources\views/users/authorize.blade.php ENDPATH**/ ?>