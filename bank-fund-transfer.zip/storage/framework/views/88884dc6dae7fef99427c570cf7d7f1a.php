<?php $__env->startSection('content'); ?>

<div class="dashboard-hero-content text-white">
    <h3 class="title"><?php echo e($page_title); ?></h3>
    <ul class="breadcrumb">
        <li class="nav-item">  <a class="nav-link " href="index.html">Home</a> </li>
        <li>
            <?php echo e($page_title); ?>

        </li>
    </ul>
</div>
</div>
<div class="container-fluid">
    <div class="deposit">
        <div class="deposit-wrapper">
            <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="deposit-item">
                <div class="deposit-inner">
                    <div class="deposit-header">
                        <h3 class="title"><?php echo e(__($data->name)); ?></h3>
                    </div>
                    <div class="deposit-body">

                        <div class="item">
                            <div class="item-thumb">
                                <img src="<?php echo e(asset('assets/images/banks/' . $data->image)); ?>" >
                            </div>
                        </div>
                            <div class="item-content">
                                <p><?php echo app('translator')->get('Limit'); ?> : <?php echo e(formatter_money($data->minimum_limit)); ?> - <?php echo e(formatter_money($data->maximum_limit)); ?> <?php echo e($gnl->cur); ?></p>
                                <p><?php echo app('translator')->get('Charge'); ?> : <?php echo e($data->percent_charge+0); ?> % + <?php echo e(formatter_money($data->fixed_charge)); ?> <?php echo e($gnl->cur); ?></p>
                                <p><?php echo app('translator')->get('Processing Time'); ?> : <?php echo e($data->processing_time); ?></p>

                                
                                <a class="nav-link custom-button" href="<?php echo e(route('user.sendmoney.single', [slug(__($data->name)) , $data->id])); ?>">Send Now </a>
                            </div>
                        </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\newproject\bank-fund-transfer\resources\views/users/others_bank/send_money.blade.php ENDPATH**/ ?>