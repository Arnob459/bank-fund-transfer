<body id="toggle-dark">
    <div id="app" >


<div id="sidebar" class="active">


    <div class="sidebar-wrapper  active">

            <div class=" d-flex justify-content-center m-4 " >
                    <a href="<?php echo e(route('admin.dashboard')); ?>"><img height="50vh" src="<?php echo e(asset('assets/images/logo/'. $gnl->logo )); ?>" alt="Logo" srcset=""></a>
            </div>

                <div class="sidebar-toggler  x">
                    <a href="#" class="sidebar-hide d-xl-none d-block"><i class="bi bi-x bi-middle"></i></a>
                </div>


        <div class="sidebar-menu">
            <ul class="menu">


                <li
                    class="sidebar-item <?php echo e(Route::is('admin.dashboard') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="sidebar-link">
                        <i class="fas fa-home"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li
                class="sidebar-item <?php echo e(Route::is('admin.accounts') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.accounts')); ?>" class="sidebar-link">
                    <i class="fas fa-university"></i>
                    <span>accounts</span>
                </a>
            </li>

                <li
                class="sidebar-item  has-sub">
                <a href="#" class='sidebar-link'>
                    <i class="far fa-arrow-alt-circle-left"></i>
                    <span>Requests</span>
                </a>
                <ul class="submenu ">

                    <li class="submenu-item <?php echo e(Route::is('admin.ownbank.request.pending') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.ownbank.request.pending')); ?>">Pending Requests</a>
                    </li>
                    <li class="submenu-item <?php echo e(Route::is('admin.ownbank.request.approved') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.ownbank.request.approved')); ?>">Approved Requests</a>
                    </li>
                    <li class="submenu-item <?php echo e(Route::is('admin.ownbank.request.rejected') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.ownbank.request.rejected')); ?>">Rejected Requests</a>
                    </li>
                    <li class="submenu-item <?php echo e(Route::is('admin.ownbank.request.log') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.ownbank.request.log')); ?>">All Requests</a>
                    </li>
                </ul>
                </li>

                <li
                class="sidebar-item  has-sub">
                <a href="#" class='sidebar-link'>
                    <i class="fas fa-random"></i>
                    <span>Send Money</span>
                </a>
                <ul class="submenu ">

                    <li class="submenu-item <?php echo e(Route::is('admin.ownbank.transfer.pending') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.ownbank.transfer.pending')); ?>">Pending transfers</a>
                    </li>
                    <li class="submenu-item <?php echo e(Route::is('admin.ownbank.transfer.approved') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.ownbank.transfer.approved')); ?>">Approved transfers</a>
                    </li>
                    <li class="submenu-item <?php echo e(Route::is('admin.ownbank.transfer.rejected') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.ownbank.transfer.rejected')); ?>">Rejected transfers</a>
                    </li>
                    <li class="submenu-item <?php echo e(Route::is('admin.ownbank.transfer.log') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.ownbank.transfer.log')); ?>">All transfers</a>
                    </li>
                </ul>
                </li>
                <li class="sidebar-item <?php echo e(Route::is('admin.banks.index') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.banks.index')); ?>" class="sidebar-link">
                    <i class="fas fa-university"></i>
                    <span> Banks</span>
                </a>
                </li>

                <li class="sidebar-item <?php echo e(Route::is('admin.branches') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.branches')); ?>" class="sidebar-link">
                    <i class="fas fa-code-branch"></i>
                    <span> Branch</span>
                </a>
                </li>

                <li class="sidebar-item <?php echo e(Route::is('admin.card.types') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.card.types')); ?>" class="sidebar-link">
                        <i class="fas fa-credit-card"></i>
                        <span> Card Type</span>
                    </a>
                </li>

                <li class="sidebar-item <?php echo e(Route::is('admin.cards') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.cards')); ?>" class="sidebar-link">
                        <i class="fas fa-address-card"></i>
                        <span> Cards</span>
                    </a>
                </li>

                <li
                class="sidebar-item  has-sub">
                <a href="#" class='sidebar-link'>
                    <i class="fas fa-random"></i>
                    <span>Transfer/Other Banks</span>
                </a>
                <ul class="submenu ">

                    <li class="submenu-item <?php echo e(Route::is('admin.transfer.pending') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.transfer.pending')); ?>">Pending transfers</a>
                    </li>
                    <li class="submenu-item <?php echo e(Route::is('admin.transfer.approved') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.transfer.approved')); ?>">Approved transfers</a>
                    </li>
                    <li class="submenu-item <?php echo e(Route::is('admin.transfer.rejected') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.transfer.rejected')); ?>">Rejected transfers</a>
                    </li>
                    <li class="submenu-item <?php echo e(Route::is('admin.transfer.log') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.transfer.log')); ?>">All transfers</a>
                    </li>
                </ul>
            </li>

                <li class="sidebar-title">MANAGE USERS</li>

                <li
                    class="sidebar-item has-sub">
                    <a href="" class='sidebar-link'>
                        <i class="fas fa-users-cog"></i>
                        <span>Users Management</span>
                    </a>
                    <ul class="submenu ">
                        <li class="submenu-item <?php echo e(Route::is('admin.allusers') ? 'active' : ''); ?> ">
                            <a href="<?php echo e(route('admin.allusers')); ?>">All Users</a>
                        </li>
                        <li class="submenu-item <?php echo e(Route::is('admin.activeusers') ? 'active' : ''); ?> ">
                            <a href="<?php echo e(route('admin.activeusers')); ?>">Active Users</a>
                        </li>
                        <li class="submenu-item <?php echo e(Route::is('admin.pendingusers') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.pendingusers')); ?>">Pending Users</a>
                        </li>
                        <li class="submenu-item <?php echo e(Route::is('admin.blockedusers') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.blockedusers')); ?>">Block Users</a>
                        </li>
                        <li class="submenu-item <?php echo e(Route::is('admin.kycunverified') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.kycunverified')); ?>">Kyc Unverified</a>
                        </li>
                        <li class="submenu-item <?php echo e(Route::is('admin.kycverified') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.kycverified')); ?>">Kyc Verified</a>
                        </li>
                        <li class="submenu-item <?php echo e(Route::is('admin.emailunverified') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.emailunverified')); ?>">Email Unverified</a>
                        </li>
                        <li class="submenu-item <?php echo e(Route::is('admin.smsunverified') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.smsunverified')); ?>">Sms Unverified</a>
                        </li>

                    </ul>
                </li>

                <li class="sidebar-title">BASIC SETTINGS</li>
                <li class="sidebar-item  has-sub">
                    <a href="#" class='sidebar-link'>
                        <i class="fas fa-cogs"></i>
                        <span>Basic Settings</span>
                    </a>
                    <ul class="submenu ">
                        <li class="submenu-item <?php echo e(Route::is('admin.settings') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.settings')); ?>">Basic</a>
                        </li>
                        <li class="submenu-item <?php echo e(Route::is('admin.logo') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.logo')); ?>">Logo & favicon</a>
                        </li>
                        <li class="submenu-item <?php echo e(Route::is('admin.contact') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.contact')); ?>">Contact</a>
                        </li>
                        <li class="submenu-item <?php echo e(Route::is('admin.social.create') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.social.create')); ?>">Social</a>
                        </li>
                        <li class="submenu-item <?php echo e(Route::is('admin.footer') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.footer')); ?>">Footer Section</a>
                        </li>

                    </ul>
                </li>

                <li
                class="sidebar-item  has-sub">
                <a href="#" class='sidebar-link'>
                    <i class="fas fa-book"></i>
                    <span>Subscribers</span>
                </a>
                <ul class="submenu ">
                    <li class="submenu-item <?php echo e(Route::is('admin.subscribers') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.subscriber')); ?>">Subscribers</a>
                    </li>
                    <li class="submenu-item <?php echo e(Route::is('admin.subscribers.mail') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.subscriber.mail')); ?>">Mail to Subscribers</a>
                    </li>
                </ul>
            </li>

                <li class="sidebar-title">Home Management</li>
                <li class="sidebar-item  has-sub">
                    <a href="#" class='sidebar-link'>
                        <i class="fas fa-book"></i>
                        <span>Home Page</span>
                    </a>
                    <ul class="submenu ">
                        <li class="submenu-item <?php echo e(Route::is('admin.banner') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.banner')); ?>">Banner</a>
                        </li>
                         <li class="submenu-item <?php echo e(Route::is('admin.slider') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.slider')); ?>">Slider</a>
                        </li>

                        <li class="submenu-item <?php echo e(Route::is('admin.services') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.services')); ?>">Services</a>
                        </li>

                       <li class="submenu-item <?php echo e(Route::is('admin.about') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.about')); ?>">About Us</a>
                        </li>
                        <li class="submenu-item <?php echo e(Route::is('admin.counter') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.counter')); ?>">Counter Section</a>
                        </li>
                        <li class="submenu-item <?php echo e(Route::is('admin.work') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.work')); ?>">How it's Work</a>
                        </li>
                         <li class="submenu-item <?php echo e(Route::is('admin.faq') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.faq')); ?>">Faq </a>
                        </li>
                        <li class="submenu-item <?php echo e(Route::is('admin.choose') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.choose')); ?>">Why Choose Us </a>
                        </li>
                        <li class="submenu-item <?php echo e(Route::is('admin.testimonial') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.testimonial')); ?>">Testimonial</a>
                        </li>
                        <li class="submenu-item <?php echo e(Route::is('admin.blog') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.blog')); ?>">Blog</a>
                        </li>
                        
                        <li class="submenu-item <?php echo e(Route::is('admin.privacy') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.privacy')); ?>">Privacy </a>
                        </li>
                        <li class="submenu-item <?php echo e(Route::is('admin.terms') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.terms')); ?>">Terms</a>
                        </li>

                    </ul>
                </li>

                <li class="sidebar-item  has-sub">
                    <a href="#" class='sidebar-link'>
                        <i class="fas fa-envelope"></i>
                        <span>Email Manager</span>
                    </a>
                    <ul class="submenu ">
                        <li class="submenu-item <?php echo e(Route::is('admin.global-template') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.global-template')); ?>">Global Templete</a>
                        </li>
                        <li class="submenu-item <?php echo e(Route::is('admin.email-template') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.email-template')); ?>">Email Templetes</a>
                        </li>
                         <li class="submenu-item <?php echo e(Route::is('admin.email-template-setting') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.email-template-setting')); ?>">Email Configure</a>
                        </li>

                    </ul>
                </li>
                



            </ul>
        </div>
    </div>

</div>
<?php /**PATH F:\newproject\bank-fund-transfer\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>