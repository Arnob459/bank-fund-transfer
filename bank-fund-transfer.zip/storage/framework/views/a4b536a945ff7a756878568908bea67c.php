<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"><?php echo e($page_title); ?>  </h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table  class="table  table-hover" >
                            <thead>
                            <tr>
                                <th >Date</th>
                                <th >Trx Number</th>
                                <th >Sender</th>
                                <th >Receiver</th>
                                <th >Amount</th>
                                <th >Charge</th>
                                <th >After Charge</th>
                                <th >Payable</th>

                                <th >Status</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $transfers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transfer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e(show_datetime($transfer->created_at)); ?></td>
                                    <td class="font-weight-bold"><?php echo e(strtoupper($transfer->trx)); ?></td>
                                    <td><a href="<?php echo e(route('admin.user.edit', $transfer->user_id)); ?>"><?php echo e($transfer->user->username); ?></a></td>
                                    <td><a href="<?php echo e(route('admin.user.edit', $transfer->receiver_id)); ?>"><?php echo e($transfer->receiver->username); ?></a></td>
                                    <td class="budget font-weight-bold"><?php echo e($gnl->cur_sym); ?><?php echo e($transfer->amount +0); ?> </td>
                                    <td class="budget text-danger"><?php echo e($gnl->cur_sym); ?><?php echo e(formatter_money($transfer->charge)); ?></td>
                                    <td class="budget"><?php echo e($gnl->cur_sym); ?> <?php echo e(formatter_money($transfer->after_charge)); ?></td>

                                    <td class="budget font-weight-bold"><?php echo e($gnl->cur_sym); ?><?php echo e(formatter_money($transfer->final_amount)); ?>  </td>

                                    <td>
                                        <?php if($transfer->status == 2): ?>
                                            <span class="badge bg-warning"><?php echo app('translator')->get('Pending'); ?></span>
                                        <?php elseif($transfer->status == 1): ?>
                                            <span class="badge bg-success"><?php echo app('translator')->get('Approved'); ?></span>
                                        <?php elseif($transfer->status == 3): ?>
                                            <span class="badge bg-danger"><?php echo app('translator')->get('Rejected'); ?></span>
                                        <?php endif; ?>
                                    </td>



                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-muted text-center" colspan="100%"><?php echo e($empty_message); ?></td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                        <ul class="pagination-overfollow">
                            <p><?php echo e($transfers->appends(array_filter(Request::all()))->links( "pagination::bootstrap-5")); ?></p>
                        </ul>

                    </div>
                </div>
            </div>
        </div>
    </div>




<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\newproject\bank-fund-transfer\resources\views/admin/transfer/ownbank_requests.blade.php ENDPATH**/ ?>