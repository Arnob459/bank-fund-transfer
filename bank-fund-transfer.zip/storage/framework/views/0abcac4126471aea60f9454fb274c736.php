<?php $__env->startSection('content'); ?>
        <div class="dashboard-inner-content">
            <div class="card">
                <h5 class="card-header"><?php echo e($page_title); ?></h5>
                <div class="card-body">
                    <form action="<?php echo e(route('user.sendmoney.submit', $bank->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" class="fixed_charge" value="<?php echo e(formatter_money($bank->fixed_charge)); ?>">
                        <input type="hidden" id="percent_charge" value="<?php echo e($bank->percent_charge+0); ?>">
                        <input type="hidden" class="minimum_amount" value="<?php echo e(formatter_money($bank->minimum_limit)); ?>">
                        <input type="hidden" class="maximum_amount" value="<?php echo e(formatter_money($bank->maximum_limit)); ?>">
                        <div class="row">
                            <div class="col-xl-6 col-lg-6">
                                <label for="a-trans"><?php echo app('translator')->get('Transfer Amount'); ?></label>
                                <input type="text" class="amount" name="amount" placeholder="enter amount"
                                       onkeyup="this.value = this.value.replace (/^\.|[^\d\.]/g, '')" required>
                            </div>
                            <div class="col-xl-6 col-lg-6">
                                <label id="limit_label"><?php echo app('translator')->get('Limit'); ?> : <?php echo e($gnl->cur); ?></label>
                                <input class="" type="text" style="border: 2px red" id="limit" readonly="readonly" value="<?php echo e(formatter_money($bank->minimum_limit)); ?> - <?php echo e(formatter_money($bank->maximum_limit)); ?> <?php echo e($gnl->cur); ?>">
                                <code class="limit"></code>
                            </div>
                            <div class="col-xl-6 col-lg-6">
                                <label
                                    for="charge"><?php echo app('translator')->get('Charge'); ?>: <?php echo e(formatter_money($bank->fixed_charge)); ?> <?php echo e($gnl->cur); ?>

                                    + <?php echo e($bank->percent_charge+0); ?> %</label>
                                <input type="text" readonly="readonly" value="0" id="charge">
                            </div>
                            <div class="col-xl-6 col-lg-6">
                                <label for="payAmount"><?php echo app('translator')->get('Amount After Charge'); ?> : <?php echo e($gnl->cur); ?></label>
                                <input type="text" value="0" id="payAmount" readonly="readonly">
                            </div>


                            <div class="col-xl-12 col-lg-12">
                                <label id="balance_limit_label"><?php echo app('translator')->get('Your Balance Will Be'); ?> : <?php echo e($gnl->cur); ?> </label>
                                <input type="text" value="<?php echo e(formatter_money(auth()->user()->balance)); ?>"
                                       id="afterBalance" readonly="readonly">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <h4 class="text-center mb-4"><?php echo app('translator')->get('Please follow the instruction bellow'); ?></h4>
                                <p class="my-4 text-center"><?php echo  $bank->description ?></p>
                                <p class="text-center mt-3 font-weight-bold"><?php echo app('translator')->get('Processing Time : '); ?> <?php echo  $bank->processing_time ?></p>
                            </div>
                            <?php $__currentLoopData = json_decode($bank->user_data); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-12">
                                    <label for="a-trans" class="font-weight-bold"><?php echo e(__($input)); ?></label>
                                    <input type="text" name="ud[<?php echo e(str_slug($input)); ?>]" placeholder="<?php echo e(__($input)); ?>"
                                           required>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="col-xl-12 col-lg-12 col-md-12 text-center">
                            <button class="btn btn-warning" id="myBtn" type="submit">Send</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(function () {
            $('.amount').keyup(function () {
                var min = parseFloat($('.minimum_amount').val()) || 0;
                var max = parseFloat($('.maximum_amount').val()) || 0;
                var amount = parseFloat($('.amount').val()) || 0;

                var balance = parseFloat(<?php echo e(formatter_money(auth()->user()->balance)); ?>) || 0;
                var fix_charge = parseFloat($('.fixed_charge').val()) || 0;
                var percent_charge = parseFloat($('#percent_charge').val()) || 0;
                var percent = (amount * percent_charge / 100);
                var charge = fix_charge + percent;
                var payAmount = amount - charge;
                var afterBalance = balance - amount;
                $('#charge').val(charge.toFixed(2));
                $('#payAmount').val(payAmount.toFixed(2));
                $('#afterBalance').val(afterBalance.toFixed(2));

                if (amount > max || amount < min) {
                    $('#limit').removeClass().addClass('error');
                    $('#limit_label').removeClass().addClass('error-label');
                    $('#myBtn').attr("disabled", true);
                    if (amount > balance) {
                        $('#afterBalance').removeClass().addClass('error');
                        $('#balance_limit_label').removeClass().addClass('error-label');
                        $('#myBtn').attr("disabled", true);
                    } else {
                        $('#afterBalance').removeClass();
                        $('#balance_limit_label').removeClass();
                        $('#myBtn').attr("disabled", false);
                    }

                } else {
                    $('#limit').removeClass();
                    $('#limit_label').removeClass();
                    if (amount > balance) {
                        $('#afterBalance').removeClass().addClass('error');
                        $('#balance_limit_label').removeClass().addClass('error-label');
                        $('#myBtn').attr("disabled", true);
                    } else {
                        $('#afterBalance').removeClass();
                        $('#balance_limit_label').removeClass();
                        $('#myBtn').attr("disabled", false);
                    }
                }
            });
        });
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('users.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\newproject\bank-fund-transfer\resources\views/users/others_bank/single.blade.php ENDPATH**/ ?>