<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">

                <div class="card-header">
                    <div class="card-title"><?php echo app('translator')->get('Edit Social Link'); ?></div>
                </div>
                <form id="socialForm" action="<?php echo e(route('admin.settings.social.update', $icon->id)); ?>" method="post"
                      onsubmit="store(event)">
                    <?php echo csrf_field(); ?>
                    <div class="card-body pt-5 pb-5">
                        <div class="row justify-content-center">
                            <div class="form-group col-md-3">
                                <label for=""><?php echo app('translator')->get('Social Icon'); ?>*</label>
                                <div class="btn-group d-block">
                                    <button type="button" class="btn btn-secondary iconpicker-component"><i
                                            class="<?php echo e($icon->icon); ?>"></i></button>
                                    <button type="button" class="icp icp-dd btn btn-secondary dropdown-toggle"
                                            data-selected="fa-car" data-bs-toggle="dropdown">
                                    </button>
                                    <div class="dropdown-menu"></div>
                                    <span class="action-create"></span>
                                </div>
                                <input id="inputIcon" type="hidden" name="icon">
                                <?php if($errors->has('icon')): ?>
                                    <p class="mb-0 text-danger"><?php echo e($errors->first('icon')); ?></p>
                                <?php endif; ?>
                                <div class="mt-2">
                                    <small><?php echo app('translator')->get('info: click on the dropdown icon to select a social link icon.'); ?></small>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <label for=""><?php echo app('translator')->get('URL'); ?> *</label>
                                <input type="text" class="form-control" name="url" value="<?php echo e($icon->url); ?>"
                                       placeholder="Enter URL of your social media account">
                                <?php if($errors->has('url')): ?>
                                    <p class="mb-0 text-danger"><?php echo e($errors->first('url')); ?></p>
                                <?php endif; ?>
                            </div>

                        </div>

                    </div>
                    <div class="card-footer pt-3">
                        <div class="col-12 text-center">
                            <button type="submit" class="btn btn-success btn-block"><?php echo app('translator')->get('Submit'); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.iconpicker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\newproject\bank-fund-transfer\resources\views/admin/basic/social/edit.blade.php ENDPATH**/ ?>