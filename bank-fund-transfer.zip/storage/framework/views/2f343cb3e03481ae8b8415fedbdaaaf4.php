<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"><?php echo e($page_title); ?>  </h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table  class="table table-lg table-hover " id="table1">
                            <thead>
                            <tr>
                                <th><?php echo app('translator')->get('Name'); ?></th>
                                <th><?php echo app('translator')->get('Subject'); ?></th>
                                <th><?php echo app('translator')->get('Status'); ?></th>
                                <th><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php $__currentLoopData = $email_templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($template->name); ?></td>
                                    <td><?php echo e($template->subj); ?></td>
                                    <td>
                                    <span class="badge bg-dot">
                                        <?php if($template->email_status == 1): ?>
                                            <i class="badge bg-success"></i>
                                            <span class="status"><?php echo app('translator')->get('active'); ?></span>
                                        <?php else: ?>
                                            <i class="badge bg-danger"></i>
                                            <span class="status"><?php echo app('translator')->get('disabled'); ?></span>
                                        <?php endif; ?>
                                    </span>
                                    </td>
                                    <td>

                                        <div class="form-button-action">
                                            <a href="<?php echo e(route('admin.email-template.edit', $template->id)); ?>"  data-toggle="tooltip" title="" class="btn  btn-primary btn-lg" data-original-title="Edit">
                                                <i class="fa fa-edit"></i>
                                            </a>
                                        </div>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('datatable'); ?>
<script src="https://cdn.datatables.net/v/bs5/dt-1.12.1/datatables.min.js"></script>
<script src="<?php echo e(asset('assets/admin/js/pages/datatables.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\newproject\bank-fund-transfer\resources\views/admin/email_template/index.blade.php ENDPATH**/ ?>