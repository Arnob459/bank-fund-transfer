<?php $__env->startSection('content'); ?>
 <!-- Content
  ============================================= -->
  <div id="content" class="py-4">
    <div class="container">
      <div class="row">

        <!-- Left Panel
        ============================================= -->
        <aside class="col-lg-3">

            <!-- Profile Details
            =============================== -->
            <div class="bg-white shadow-sm rounded text-center p-3 mb-4">
              <div class="profile-thumb mt-3 mb-4">
                <?php if(auth()->user()->avatar == null): ?>
                <img class="rounded-circle" src="<?php echo e(asset('assets/images/users/2.jpg')); ?>" alt="">
                <?php else: ?>
                <img class="rounded-circle" src="<?php echo e(asset('assets/images/users/'.auth()->user()->avatar)); ?>" alt="">
            <?php endif; ?>
            <?php if(auth()->user()->kyc_verify == 1): ?>
            <div class="profile-thumb-edit bg-primary text-white" data-bs-toggle="tooltip" title="Verified"> <i class="fas fa-check position-absolute"></i>
            </div>
            <?php endif; ?>
              </div>
              <p class="text-3 fw-500 mb-2">Hello, <?php echo e(auth()->user()->username); ?></p>
              <p class="mb-2"><a href="<?php echo e(route('user.profile')); ?>" class="text-5 text-light" data-bs-toggle="tooltip" title="Edit Profile"><i class="fas fa-edit"></i></a></p>
            </div>
            <!-- Profile Details End -->

            <!-- Available Balance
            =============================== -->
            <div class="bg-white shadow-sm rounded text-center p-3 mb-4">
              <div class="text-17 text-light my-3"><i class="fas fa-wallet"></i></div>
              <h3 class="text-9 fw-400"><?php echo e($gnl->cur_sym); ?> <?php echo e(formatter_money(auth()->user()->balance)); ?> </h3>
              <p class="mb-2 text-muted opacity-8">Available Balance</p>
            </div>
            <!-- Available Balance End -->


          </aside>
        <!-- Left Panel End -->

        <!-- Middle Panel
        ============================================= -->
        <div class="col-lg-9">
          <h2 class="fw-400 mb-3">Transactions</h2>

          <!-- Filter
          ============================================= -->
          <div class="row">
            <div class="col mb-2">
              <form id="filterTransactions" method="post">
                <div class="row g-3 mb-3">
                  <!-- Date Range
                  ========================= -->
                  <div class="col-sm-6 col-md-5">
                    <div class="position-relative">
					<input id="dateRange" type="text" class="form-control" placeholder="Date Range">
                    <span class="icon-inside"><i class="fas fa-calendar-alt"></i></span>
					</div>
				  </div>

                </div>
              </form>
            </div>
          </div>
          <!-- Filter End -->

          <!-- All Transactions
          ============================================= -->
          <div class="bg-white shadow-sm rounded py-4 mb-4">
            <h3 class="text-5 fw-400 d-flex align-items-center px-4 mb-4">All Transactions</h3>
            <!-- Title
            =============================== -->
            <div class="transaction-title py-2 px-4">
              <div class="row">
                <div class="col-2 col-sm-2 text-center"><span class="">Date</span></div>
                <div class="col col-sm-3">Description</div>
                <div class="col-auto col-sm-4 d-none d-sm-block text-center">Status</div>
                <div class="col col-sm-2 text-end">Amount</div>
              </div>
            </div>
            <!-- Title End -->

            <!-- Transaction List
            =============================== -->

            <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="transaction-list">

              <div class="transaction-item px-4 py-3" data-bs-toggle="modal" data-bs-target="#transaction-detail<?php echo e($item->id); ?>">
                <div class="row align-items-center flex-row">
                  <div class="col-2 col-sm-2 text-center"> <span class="d-block text-4 fw-300"><?php echo e(\Carbon\Carbon::parse($item->created_at)->format('j M Y H:i:s')); ?></span> </div>
                  <div class="col col-sm-3"> <span class="d-block text-4"><?php if($item->bank_type == 1): ?><?php echo e($item->bank->name); ?> <?php else: ?><?php echo e($item->receiver->username); ?><?php endif; ?></span>
                 <span class="text-muted"><?php if($item->type == 0): ?>
                     Request from <?php echo e($item->receiver->username); ?>

                 <?php else: ?>
                     Send to <?php if($item->bank_type == 1): ?><?php echo e($item->bank->name); ?><?php else: ?> <?php echo e($item->receiver->username); ?> <?php endif; ?>
                 <?php endif; ?></span> </div>
                 <?php if($item->status == 2 || $item->status == 4): ?>
                 <div class="col-auto col-sm-4 d-none d-sm-block text-center text-3"> <span class="badge bg-warning text-dark text-0 fw-500 rounded-pill px-2 mb-0 ">in Process</span>  <span class="text-warning" data-bs-toggle="tooltip" title="In Progress"><i class="fas fa-ellipsis-h"></i></span> </div>
               <?php elseif($item->status == 1): ?>
               <div class="col-auto col-sm-4 d-none d-sm-block text-center text-3"> <span class="badge bg-success text-dark text-0 fw-500 rounded-pill px-2 mb-0 ">Completed</span> <span class="text-success" data-bs-toggle="tooltip" title="Completed"><i class="fas fa-check-circle"></i></span> </div>
                <?php else: ?>
                <div class="col-auto col-sm-4 d-none d-sm-block text-center text-3"> <span class="badge bg-danger text-dark text-0 fw-500 rounded-pill px-2 mb-0 ">Cancelled</span> <span class="text-danger" data-bs-toggle="tooltip" title="Cancelled"><i class="fas fa-times-circle"></i></span> </div>
                <?php endif; ?>
                  <div class="col col-sm-2 text-end text-4"> <span class="text-nowrap"> <?php echo e($gnl->cur_sym); ?><?php echo e(formatter_money($item->amount)); ?></span> <span class="text-2 text-uppercase"><?php echo e($gnl->cur); ?></span> </div>
                </div>
              </div>

            </div>

            <!-- Transaction List End -->

            <!-- Transaction Item Details Modal
            =========================================== -->
            <div id="transaction-detail<?php echo e($item->id); ?>" class="modal fade" role="dialog" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered transaction-details" role="document">
                <div class="modal-content">
                  <div class="modal-body">
                    <div class="row g-0">
                      <div class="col-sm-5 d-flex justify-content-center bg-primary rounded-start py-4">
                        <div class="my-auto text-center">
                          <div class="text-17 text-white my-3"><i class="fas fa-building"></i></div>
                          <h3 class="text-4 text-white fw-400 my-3"><?php if($item->bank_type == 1): ?><?php echo e($item->bank->name); ?> <?php else: ?><?php echo e($item->receiver->username); ?><?php endif; ?></h3>
                          <div class="text-8 fw-500 text-white my-4"><?php echo e($gnl->cur_sym); ?><?php echo e(formatter_money($item->amount)); ?></div>
                          <p class="text-white"><?php echo e(\Carbon\Carbon::parse($item->created_at)->format('j M Y H:i:s')); ?></p>
                        </div>
                      </div>
                      <div class="col-sm-7">
                        <h5 class="text-5 fw-400 m-3">Transaction Details
                          <button type="button" class="btn-close text-2 float-end" data-bs-dismiss="modal" aria-label="Close"></button>
                        </h5>
                        <hr>
                        <div class="px-3">
                          <ul class="list-unstyled">
                            <li class="mb-2"><?php if($item->type == 0): ?>Request  <?php else: ?> Send  <?php endif; ?> Amount
                                <span class="float-end text-3"><?php echo e($gnl->cur_sym); ?><?php echo e(formatter_money($item->amount)); ?></span></li>
                            <li class="mb-2">Fee <?php if($item->final_amount > $item->amount ): ?> (<?php echo e($item->receiver->username); ?> will pay the fee) <?php endif; ?>
                                <span class="float-end text-3">-<?php echo e($gnl->cur_sym); ?><?php echo e(formatter_money($item->charge)); ?></span></li>
                          </ul>
                          <hr class="mb-2">
                          <p class="d-flex align-items-center fw-500 mb-0">Total Amount <span class="text-3 ms-auto"><?php echo e($gnl->cur_sym); ?> <?php if($item->final_amount > $item->amount ): ?> <?php echo e(formatter_money($item->amount)); ?> <?php else: ?> <?php echo e(formatter_money($item->final_amount)); ?> <?php endif; ?></span></p>
						  <hr class="mb-4 mt-2">

                          <ul class="list-unstyled">
                            <li class="fw-500">Transaction ID:</li>
                            <li class="text-muted"><?php echo e($item->trx); ?></li>
                          </ul>
                          <ul class="list-unstyled">
                            <li class="fw-500">Description:</li>
                            <?php if($item->detail == Null): ?>
                              <li class="text-muted"><?php echo e($item->receiver->username); ?> </li>
                              <li class="text-muted"><?php echo e($item->receiver->name); ?> </li>
                              <li class="text-muted"><?php echo e($item->receiver->email); ?> </li>

                            <?php else: ?>

                            <?php $__currentLoopData = json_decode($item->detail); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="text-muted"><?php echo e($key); ?>: <?php echo e($data); ?> </li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                          </ul>
                          <?php if($item->status == 3): ?>
                          <ul class="list-unstyled">
                            <li class="fw-500">Admin Feedback:</li>
                            <li class="text-muted"><?php echo e($item->admin_feedback); ?></li>
                          </ul>
                          <?php endif; ?>

                          <ul class="list-unstyled">
                            <li class="fw-500">Status:</li>
                            <?php if($item->status == 2 || $item->status == 4): ?>
                            <li class="text-muted">in Process<span class="text-warning text-3 ms-1"><i class="fas fa-ellipsis-h"></i></span></li>
                          <?php elseif($item->status == 1): ?>
                          <li class="text-muted">Completed<span class="text-success text-3 ms-1"><i class="fas fa-check-circle"></i></span></li>
                           <?php else: ?>
                           <li class="text-muted">Cancelled<span class="text-danger text-3 ms-1"><i class="fas fa-times-circle"></i></span></li>
                           <?php endif; ?>

                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- Transaction Item Details Modal End -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if(count($logs) == 0): ?>
            <div class="transaction-list">
                <div class="transaction-item px-4 py-3" >
                  <div class=" align-items-center ">
                    <div class=" text-center"> <span class="d-block text-4 fw-300">No Transections</span> </div>
                  </div>
                </div>
              </div>
            <?php endif; ?>




            <!-- Pagination
            ============================================= -->
            <ul class="justify-content-center mt-4 mb-0">
                <?php echo e($logs->links( "pagination::bootstrap-5")); ?>

            </ul>
            <!-- Paginations end -->

          </div>
          <!-- All Transactions End -->

        </div>
        <!-- Middle End -->
      </div>
    </div>
  </div>
  <!-- Content end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\newproject\bank-fund-transfer\resources\views/user/transactions.blade.php ENDPATH**/ ?>