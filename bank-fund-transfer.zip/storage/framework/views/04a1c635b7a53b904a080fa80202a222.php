<?php $__env->startPush('button'); ?>
<a href="<?php echo e(route('admin.banks.create')); ?>" class="btn btn-warning ">Add New Bank</a>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"><?php echo e($page_title); ?></h4>
                </div>
                <div class="card-body">
                        <table class="table table-hover table-responsive" id="table1">
                            <thead>
                            <tr>
                                <th><?php echo app('translator')->get('Sl'); ?></th>
                                <th><?php echo app('translator')->get('Image'); ?></th>
                                <th><?php echo app('translator')->get('Bank'); ?></th>
                                <th><?php echo app('translator')->get('Status'); ?></th>
                                <th><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($key+1); ?>

                                    </td>
                                    <td>
                                        <div class="avatar">
                                            <img src="<?php echo e(asset('assets/images/banks/'.$bank->image)); ?>" alt="..." class="avatar-img rounded-circle">
                                        </div>
                                    </td>
                                    <td><?php echo e($bank->name); ?> <?php if($bank->primary == 1): ?>
                                    <span class="badge rounded-pill bg-primary"><?php echo app('translator')->get('primary'); ?></span><?php endif; ?>  </td>
                                    <td>
                                        <?php if($bank->status == 1): ?>
                                        <span class="badge rounded-pill bg-success"><?php echo app('translator')->get('active'); ?></span>
                                        <?php else: ?>
                                            <span class="badge rounded-pill bg-danger"><?php echo app('translator')->get('disabled'); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a class="btn btn-secondary btn-sm"
                                           href="<?php echo e(route('admin.banks.edit', $bank->id)); ?>">
                                            <span class="btn-label"><i class="fas fa-edit"></i></span><?php echo app('translator')->get('Edit'); ?></a>
                                        <?php if($bank->status == 0): ?>
                                            <button class="btn btn-success btn-sm"
                                            data-bs-toggle="modal" data-bs-target="#deactivateModal<?php echo e($bank->id); ?>" >
                                                <span class="btn-label"><i class="fas fa-eye"></i></span>
                                                <?php echo app('translator')->get('Active'); ?>
                                            </button>
                                        <?php else: ?>
                                            <button class="btn btn-danger btn-sm"
                                            data-bs-toggle="modal" data-bs-target="#activateModal<?php echo e($bank->id); ?>" >
                                                <span class="btn-label"><i class="fas fa-eye-slash"></i></span>
                                                <?php echo app('translator')->get('Disable'); ?>
                                            </button>
                                        <?php endif; ?>
                                    </td>

                                </tr>
                                    
                                        <div class="modal fade" id="activateModal<?php echo e($bank->id); ?>" tabindex="-1" role="dialog" aria-labelledby="activateModalLabel<?php echo e($bank->id); ?>" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="activateModalLabel<?php echo e($bank->id); ?>">Payment Method Disable!!</h5>
                                                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        Are you sure want to disable <?php echo e($bank->name); ?> ?
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">NO</button>
                                                        <form method="POST" action="<?php echo e(route('admin.banks.deactivate')); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" name="id" value="<?php echo e($bank->id); ?>">
                                                            <button type="submit" class="btn btn-success">YES</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    
                                    
                                        <div class="modal fade" id="deactivateModal<?php echo e($bank->id); ?>" tabindex="-1" role="dialog" aria-labelledby="deactivateModalLabel<?php echo e($bank->id); ?>" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="deactivateModalLabel<?php echo e($bank->id); ?>">Bank Activation!!</h5>
                                                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        Are you sure to activate <?php echo e($bank->name); ?> ?
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">NO</button>
                                                        <form method="POST" action="<?php echo e(route('admin.banks.activate')); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" name="id" value="<?php echo e($bank->id); ?>">
                                                            <button type="submit" class="btn btn-success">YES</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('datatable'); ?>
<script src="https://cdn.datatables.net/v/bs5/dt-1.12.1/datatables.min.js"></script>
<script src="<?php echo e(asset('assets/admin/js/pages/datatables.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\newproject\bank-fund-transfer\resources\views/admin/bank/list.blade.php ENDPATH**/ ?>