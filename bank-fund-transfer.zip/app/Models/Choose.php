<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Choose extends Model
{
    protected $table = 'chooses';
    public $timestamps = false;
}
